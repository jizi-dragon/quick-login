"use strict";
(() => {
  // packages/extension/src/shared/constants.ts
  var EXT_VERSION = "3.7.2";
  var IDB_NAME = "sessionbox-reborn";
  var IDB_VERSION = 2;
  var IDB_STORE_SESSIONS = "sessions";
  var IDB_STORE_ACCOUNTS = "accounts";
  var SESSION_KEYS = {
    sessionTabBindings: "sb:tabBindings",
    pendingAutoLogins: "sb:pendingAutoLogins",
    /** 并行账号的 tabId ↔ accountId 绑定表 */
    parTabBindings: "ql:parTabBindings",
    /** 并行账号捕获到的运行时凭证快照（Bearer token 等，随浏览器会话存活） */
    parTokens: "ql:parTokens"
  };
  var LOCAL_KEYS = {
    siteGrants: "sb:siteGrants",
    /** 手动停用的站点（Chrome 拒绝回收授权时本地封锁，不再对其安装改头规则） */
    blockedHosts: "ql:blockedHosts"
  };
  var CONTENT_MESSAGE = {
    setTitle: "sb:setTitle",
    autoLogin: "sb:autoLogin",
    autoLoginRequest: "sb:autoLoginRequest",
    /** ISOLATED 桥 → background（双向通路的上行） */
    bridgeUp: "ql:bridgeUp",
    /** background → ISOLATED 桥（下行） */
    bridgeDown: "ql:bridgeDown"
  };
  var SESSION_COLORS = [
    "#1E6FFF",
    "#0FA3B1",
    "#7C5CFF",
    "#FF7A1A",
    "#22C55E"
  ];

  // packages/extension/src/storage/db.ts
  function openDb() {
    return new Promise((resolve, reject) => {
      const req = indexedDB.open(IDB_NAME, IDB_VERSION);
      req.onupgradeneeded = () => {
        const db2 = req.result;
        if (!db2.objectStoreNames.contains(IDB_STORE_SESSIONS)) {
          db2.createObjectStore(IDB_STORE_SESSIONS, { keyPath: "id" });
        }
        if (!db2.objectStoreNames.contains(IDB_STORE_ACCOUNTS)) {
          db2.createObjectStore(IDB_STORE_ACCOUNTS, { keyPath: "id" });
        }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
    });
  }
  function tx(store, mode, run) {
    return openDb().then(
      (db2) => new Promise((resolve, reject) => {
        const t = db2.transaction(store, mode);
        const req = run(t.objectStore(store));
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
      })
    );
  }
  var db = {
    sessions: {
      async list() {
        return tx(IDB_STORE_SESSIONS, "readonly", (s) => s.getAll());
      },
      async get(id) {
        return tx(IDB_STORE_SESSIONS, "readonly", (s) => s.get(id));
      },
      async put(session) {
        await tx(IDB_STORE_SESSIONS, "readwrite", (s) => s.put(session));
      },
      async delete(id) {
        await tx(IDB_STORE_SESSIONS, "readwrite", (s) => s.delete(id));
      }
    },
    accounts: {
      async list() {
        return tx(IDB_STORE_ACCOUNTS, "readonly", (s) => s.getAll());
      },
      async get(id) {
        return tx(IDB_STORE_ACCOUNTS, "readonly", (s) => s.get(id));
      },
      async put(account) {
        await tx(IDB_STORE_ACCOUNTS, "readwrite", (s) => s.put(account));
      },
      async delete(id) {
        await tx(IDB_STORE_ACCOUNTS, "readwrite", (s) => s.delete(id));
      }
    }
  };

  // packages/extension/src/background/core/session-manager.ts
  function newId() {
    return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  }
  var sessionManager = {
    list() {
      return db.sessions.list();
    },
    async get(id) {
      return db.sessions.get(id);
    },
    async getOrThrow(id) {
      const session = await db.sessions.get(id);
      if (!session) {
        throw new Error(`\u4F1A\u8BDD\u4E0D\u5B58\u5728: ${id}`);
      }
      return session;
    },
    async create(input) {
      const now = Date.now();
      const existing = await db.sessions.list();
      const session = {
        id: newId(),
        name: input.name || input.accountAlias || input.siteHost,
        accountAlias: input.accountAlias,
        siteHost: input.siteHost,
        color: SESSION_COLORS[existing.length % SESSION_COLORS.length],
        createdAt: now,
        updatedAt: now
      };
      await db.sessions.put(session);
      return session;
    },
    async update(id, patch) {
      const session = await db.sessions.get(id);
      if (!session) {
        throw new Error(`\u4F1A\u8BDD\u4E0D\u5B58\u5728: ${id}`);
      }
      const next = { ...session, ...patch, updatedAt: Date.now() };
      await db.sessions.put(next);
      return next;
    },
    /** 保存/更新加密后的账号密码 */
    async updateCredentials(id, credentials2) {
      const session = await db.sessions.get(id);
      if (!session) {
        throw new Error(`\u4F1A\u8BDD\u4E0D\u5B58\u5728: ${id}`);
      }
      const next = { ...session, credentials: credentials2, updatedAt: Date.now() };
      await db.sessions.put(next);
      return next;
    },
    /** 删除会话记录；已打开的标签页不受影响（绑定按标签关闭清理） */
    async delete(id) {
      await db.sessions.delete(id);
    }
  };

  // packages/extension/src/background/core/account-registry.ts
  var cache = /* @__PURE__ */ new Map();
  var accountRegistry = {
    async getAlias(sessionId) {
      const hit = cache.get(sessionId);
      if (hit !== void 0) {
        return hit;
      }
      const session = await sessionManager.get(sessionId);
      const alias = session?.accountAlias || session?.name;
      if (session) {
        cache.set(sessionId, alias ?? "");
      }
      return alias;
    },
    invalidate(sessionId) {
      if (sessionId) {
        cache.delete(sessionId);
      } else {
        cache.clear();
      }
    }
  };

  // packages/extension/src/background/core/credentials.ts
  var credentials = {
    /** 获取或生成加密密钥种子 */
    async getKeySeed() {
      const stored = await chrome.storage.local.get("sb:encryptionSeed");
      let seed = stored["sb:encryptionSeed"];
      if (!seed) {
        seed = crypto.randomUUID();
        await chrome.storage.local.set({ "sb:encryptionSeed": seed });
      }
      return seed;
    },
    /** 从种子派生加密密钥 */
    async deriveKey(seed) {
      const encoder = new TextEncoder();
      const keyMaterial = await crypto.subtle.importKey(
        "raw",
        encoder.encode(seed),
        { name: "PBKDF2" },
        false,
        ["deriveKey"]
      );
      const salt = encoder.encode("sessionbox-salt-v1");
      return crypto.subtle.deriveKey(
        {
          name: "PBKDF2",
          salt,
          iterations: 1e5,
          hash: "SHA-256"
        },
        keyMaterial,
        { name: "AES-GCM", length: 256 },
        false,
        ["encrypt", "decrypt"]
      );
    },
    /** 加密单个字符串 */
    async encryptValue(plaintext, key) {
      const encoder = new TextEncoder();
      const iv = crypto.getRandomValues(new Uint8Array(12));
      const ciphertext = await crypto.subtle.encrypt(
        { name: "AES-GCM", iv },
        key,
        encoder.encode(plaintext)
      );
      return {
        encrypted: btoa(String.fromCharCode(...new Uint8Array(ciphertext))),
        iv: btoa(String.fromCharCode(...iv))
      };
    },
    /** 解密单个字符串 */
    async decryptValue(encrypted, iv, key) {
      const ciphertext = Uint8Array.from(atob(encrypted), (c) => c.charCodeAt(0));
      const ivBytes = Uint8Array.from(atob(iv), (c) => c.charCodeAt(0));
      const plaintext = await crypto.subtle.decrypt(
        { name: "AES-GCM", iv: ivBytes },
        key,
        ciphertext
      );
      return new TextDecoder().decode(plaintext);
    },
    /** 加密账号密码 */
    async encryptCredentials(username, password) {
      const seed = await this.getKeySeed();
      const key = await this.deriveKey(seed);
      const { encrypted: encUsername, iv: ivUsername } = await this.encryptValue(username, key);
      const { encrypted: encPassword, iv: ivPassword } = await this.encryptValue(password, key);
      return {
        encryptedUsername: encUsername,
        encryptedPassword: encPassword,
        iv: ivUsername,
        ivPassword,
        encryptedAt: Date.now()
      };
    },
    /** 解密账号密码 */
    async decryptCredentials(creds) {
      const seed = await this.getKeySeed();
      const key = await this.deriveKey(seed);
      const username = await this.decryptValue(creds.encryptedUsername, creds.iv, key);
      const password = await this.decryptValue(creds.encryptedPassword, creds.ivPassword, key);
      return { username, password };
    }
  };

  // packages/extension/src/background/tabs/tab-title.ts
  async function setTabTitle(tabId, alias) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        func: (title) => {
          if (document.title !== title) {
            document.title = title;
          }
        },
        args: [alias],
        world: "MAIN"
      });
    } catch {
    }
  }

  // packages/extension/src/background/core/navigation.ts
  var bindings = /* @__PURE__ */ new Map();
  async function readState() {
    const stored = await chrome.storage.session.get([SESSION_KEYS.sessionTabBindings]);
    const map = stored[SESSION_KEYS.sessionTabBindings];
    bindings.clear();
    if (map) {
      for (const [tabId, binding] of Object.entries(map)) {
        bindings.set(Number(tabId), binding);
      }
    }
  }
  async function persistBindings() {
    const map = {};
    for (const [tabId, binding] of bindings) {
      map[String(tabId)] = binding;
    }
    await chrome.storage.session.set({ [SESSION_KEYS.sessionTabBindings]: map });
  }
  function cookieUrl(c) {
    const domain = c.domain.startsWith(".") ? c.domain.slice(1) : c.domain;
    const protocol = c.secure ? "https" : "http";
    const path = c.path?.startsWith("/") ? c.path : "/";
    return `${protocol}://${domain}${path}`;
  }
  async function clearLoginState(tabId, host) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        func: () => window.localStorage.clear(),
        world: "MAIN"
      });
    } catch {
    }
    const cookies = await chrome.cookies.getAll({ domain: host });
    await Promise.all(
      cookies.map((c) => chrome.cookies.remove({ url: cookieUrl(c), name: c.name }).catch(() => null))
    );
  }
  var AUTO_LOGIN_TTL = 6e4;
  function pendingKey(tabId) {
    return `${SESSION_KEYS.pendingAutoLogins}:${tabId}`;
  }
  async function setPendingAutoLogin(tabId, username, password) {
    await chrome.storage.session.set({
      [pendingKey(tabId)]: { username, password, at: Date.now() }
    });
  }
  async function getPendingAutoLogin(tabId) {
    const key = pendingKey(tabId);
    const stored = await chrome.storage.session.get(key);
    const entry = stored[key];
    if (!entry) {
      return null;
    }
    if (Date.now() - entry.at > AUTO_LOGIN_TTL) {
      await chrome.storage.session.remove(key);
      return null;
    }
    return { username: entry.username, password: entry.password };
  }
  async function triggerAutoLogin(tabId, username, password) {
    await setPendingAutoLogin(tabId, username, password);
    try {
      await chrome.tabs.sendMessage(tabId, {
        type: CONTENT_MESSAGE.autoLogin,
        username,
        password
      });
    } catch {
    }
  }
  async function applyTitle(tabId, alias) {
    await setTabTitle(tabId, alias);
    try {
      await chrome.tabs.sendMessage(tabId, { type: CONTENT_MESSAGE.setTitle, alias });
    } catch {
    }
  }
  function findOpenTab(sessionId) {
    for (const [tabId, binding] of bindings) {
      if (binding.sessionId === sessionId) {
        return tabId;
      }
    }
    return null;
  }
  var navigation = {
    async bind(tabId, sessionId, host) {
      bindings.set(tabId, { sessionId, host });
      await persistBindings();
    },
    /**
     * 切换账号：登出当前登录态 → 导航登录页 → 用保存凭证自动登录 → 改标题。
     * 这是「免密快速切换」的核心，替代原「Cookie 罐焦点仲裁」。
     */
    async switchAccount(session, credentials2) {
      const loginUrl = `https://${session.siteHost}/login`;
      const existingTabId = findOpenTab(session.id);
      let tabId;
      let reused;
      if (existingTabId !== null) {
        tabId = existingTabId;
        reused = true;
      } else {
        const tab = await chrome.tabs.create({ url: loginUrl });
        tabId = tab.id;
        await this.bind(tabId, session.id, session.siteHost);
        reused = false;
      }
      await clearLoginState(tabId, session.siteHost);
      await chrome.tabs.update(tabId, { url: loginUrl, active: true });
      const alias = await accountRegistry.getAlias(session.id) ?? "";
      await applyTitle(tabId, alias);
      if (credentials2) {
        await triggerAutoLogin(tabId, credentials2.username, credentials2.password);
      }
      return { tabId, reused };
    },
    /** 内容脚本（含 iframe frame）就绪后主动索取自动登录凭证（只读共享，超时失效） */
    getPendingAutoLogin
  };
  function registerNavigationHandlers() {
    void readState();
    chrome.runtime.onStartup.addListener(() => {
      void readState();
    });
    chrome.tabs.onRemoved.addListener((tabId) => {
      void chrome.storage.session.remove(pendingKey(tabId));
      if (bindings.delete(tabId)) {
        void persistBindings();
      }
    });
  }

  // packages/extension/src/background/core/parallel-store.ts
  function newId2() {
    return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  }
  var parallelStore = {
    list() {
      return db.accounts.list();
    },
    async get(id) {
      const account = await db.accounts.get(id);
      if (!account) {
        throw new Error(`\u8D26\u53F7\u4E0D\u5B58\u5728: ${id}`);
      }
      return account;
    },
    async create(input) {
      const now = Date.now();
      const existing = await db.accounts.list();
      const account = {
        id: newId2(),
        siteHost: input.siteHost,
        tabName: input.tabName || input.username,
        username: input.username,
        color: SESSION_COLORS[existing.length % SESSION_COLORS.length],
        createdAt: now,
        updatedAt: now,
        credentials: await credentials.encryptCredentials(input.username, input.password)
      };
      await db.accounts.put(account);
      return account;
    },
    async updateTabName(id, tabName) {
      const account = await this.get(id);
      const next = { ...account, tabName, updatedAt: Date.now() };
      await db.accounts.put(next);
      return next;
    },
    async updateCredentials(id, creds) {
      const account = await this.get(id);
      await db.accounts.put({ ...account, credentials: creds, updatedAt: Date.now() });
    },
    async delete(id) {
      await db.accounts.delete(id);
    }
  };

  // packages/extension/src/background/core/tab-rules.ts
  var AUTH_BASE = 1e5;
  var COOKIE_BASE = 2e5;
  var installed = /* @__PURE__ */ new Map();
  async function diag(msg) {
    try {
      const key = "ql:diag";
      const cur = (await chrome.storage.local.get(key))[key];
      const next = [...(cur ?? []).slice(-59), `${(/* @__PURE__ */ new Date()).toISOString().slice(11, 23)} ${msg}`];
      await chrome.storage.local.set({ [key]: next });
    } catch {
    }
  }
  var nextAuthId = AUTH_BASE;
  var nextCookieId = COOKIE_BASE;
  var ALL_MATCH_TYPES = [
    "main_frame",
    "sub_frame",
    "xmlhttprequest",
    "websocket",
    "script",
    "stylesheet",
    "image",
    "font",
    "media",
    "other"
  ];
  function asRule(raw) {
    return raw;
  }
  function parentDomainOf(host) {
    const parts = host.split(".");
    return parts.length > 2 ? parts.slice(-2).join(".") : host;
  }
  function buildAuthRule(ruleId, host, tabId, token) {
    return asRule({
      id: ruleId,
      priority: 1,
      action: {
        type: "modifyHeaders",
        requestHeaders: [{ header: "Authorization", operation: "set", value: `Bearer ${token}` }]
      },
      condition: {
        // API 调用、WS 握手，以及 iframe 内嵌文档（低代码平台的「管理端」控制台常以
        // iframe 承载：只带命名空间存储、无 Bearer 的子框架会被服务端当匿名拒入）
        resourceTypes: ["xmlhttprequest", "websocket", "sub_frame"],
        requestDomains: [host, parentDomainOf(host)],
        tabIds: [tabId]
      }
    });
  }
  function buildCookieRule(ruleId, host, tabId, cookieHeader) {
    return asRule({
      id: ruleId,
      priority: 1,
      action: {
        type: "modifyHeaders",
        requestHeaders: [
          cookieHeader ? { header: "Cookie", operation: "set", value: cookieHeader } : { header: "Cookie", operation: "remove" }
        ]
      },
      condition: {
        // 全类型覆盖：绑定标签页的出站 Cookie 完全由本规则决定，与真实 jar 无关
        resourceTypes: ALL_MATCH_TYPES,
        requestDomains: [host, parentDomainOf(host)],
        tabIds: [tabId]
      }
    });
  }
  async function addOne(rule) {
    try {
      await chrome.declarativeNetRequest.updateSessionRules({ addRules: [rule] });
      return true;
    } catch (e) {
      void diag(`addRule #${rule.id} \u5931\u8D25\uFF1A${e instanceof Error ? e.message : String(e)}`);
      return false;
    }
  }
  var tabRules = {
    /**
     * 设置/更新某绑定标签页的网络平面规则。
     * - COOKIE 规则绑定即装：cookieHeader 非 null → set（回放），变更时重建；
     *   null → remove（剥离）。
     * - token 非 null 时装/换 AUTH 规则；null 时摘除。
     * 逐条安装：单条失败不连坐其余规则。
     */
    async applyBinding(host, tabId, token, cookieHeader) {
      const wanted = cookieHeader ?? null;
      const meta = installed.get(tabId) ?? { token: null, cookieValue: null };
      const removes = [];
      if (meta.cookieId === void 0 || meta.cookieValue !== wanted) {
        if (meta.cookieId !== void 0) {
          removes.push(meta.cookieId);
          meta.cookieId = void 0;
        }
        const ruleId = nextCookieId++;
        if (await addOne(buildCookieRule(ruleId, host, tabId, wanted))) {
          meta.cookieId = ruleId;
          meta.cookieValue = wanted;
        }
      }
      if (token === null) {
        if (meta.authId !== void 0) {
          removes.push(meta.authId);
          meta.authId = void 0;
        }
        meta.token = null;
      } else if (meta.token !== token) {
        if (meta.authId !== void 0) {
          removes.push(meta.authId);
          meta.authId = void 0;
        }
        const ruleId = nextAuthId++;
        if (await addOne(buildAuthRule(ruleId, host, tabId, token))) {
          meta.authId = ruleId;
          meta.token = token;
        }
      }
      if (removes.length) {
        try {
          await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: removes });
        } catch (e) {
          void diag(`updateRules \u79FB\u9664\u5931\u8D25 ids=${removes.join(",")}\uFF1A${e instanceof Error ? e.message : String(e)}`);
        }
      }
      installed.set(tabId, meta);
      void diag(
        `applyBinding tab=${tabId} token=${token ? "\u6709" : "\u65E0"} cookie=${wanted ? `\u56DE\u653E${wanted.length}B` : "\u5265\u79BB"} cookieId=${meta.cookieId ?? "-"} authId=${meta.authId ?? "-"}`
      );
    },
    /** 标签关闭 / 解绑：摘除其全部规则 */
    async clearTab(tabId) {
      const meta = installed.get(tabId);
      if (!meta) {
        return;
      }
      const removes = [];
      if (meta.cookieId !== void 0) {
        removes.push(meta.cookieId);
      }
      if (meta.authId !== void 0) {
        removes.push(meta.authId);
      }
      try {
        if (removes.length) {
          await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: removes });
        }
      } catch {
      }
      installed.delete(tabId);
      void diag(`clearTab tab=${tabId} del=${removes.length}`);
    },
    /**
     * SW 冷启动恢复：persisted 提供 tabId → { host, token|null }，
     * 与浏览器内现存 session 规则做差集同步（孤儿清理 + 缺失重建）。
     */
    async restore(persisted) {
      let existing = [];
      try {
        existing = await chrome.declarativeNetRequest.getSessionRules();
      } catch {
        existing = [];
      }
      const desiredTabs = new Set(persisted.keys());
      const removals = [];
      for (const rule of existing) {
        const inOurs = rule.id >= AUTH_BASE;
        const orphans = (rule.condition.tabIds ?? []).every((t) => !desiredTabs.has(t));
        if (inOurs && orphans) {
          removals.push(rule.id);
        }
      }
      if (removals.length) {
        try {
          await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: removals });
        } catch {
        }
      }
      nextAuthId = Math.max(
        AUTH_BASE,
        ...existing.filter((r) => r.id >= AUTH_BASE && r.id < COOKIE_BASE).map((r) => r.id + 1),
        AUTH_BASE
      );
      nextCookieId = Math.max(
        COOKIE_BASE,
        ...existing.filter((r) => r.id >= COOKIE_BASE).map((r) => r.id + 1),
        COOKIE_BASE
      );
      installed.clear();
      for (const [tabId, info] of persisted) {
        await this.applyBinding(info.host, tabId, info.token ?? null, info.cookie ?? null);
      }
      void diag(`tabRules.restore persisted=${persisted.size}`);
    },
    /** 诊断用内部状态快照（经 ql.diag 消息暴露给台架） */
    debugState() {
      return {
        installed: Array.from(installed.entries()).map(([t, m]) => ({
          t,
          authId: m.authId ?? null,
          cookieId: m.cookieId ?? null,
          token: m.token ? "\u6709" : "\u65E0",
          cookie: m.cookieValue ? `\u56DE\u653E${m.cookieValue.length}B` : "\u5265\u79BB"
        })),
        nextAuthId,
        nextCookieId
      };
    }
  };

  // packages/extension/src/background/core/parallel-session.ts
  var bindings2 = /* @__PURE__ */ new Map();
  var tokens = /* @__PURE__ */ new Map();
  var enforcement = /* @__PURE__ */ new Map();
  async function diag2(msg) {
    try {
      const key = "ql:diag";
      const cur = (await chrome.storage.local.get(key))[key];
      const next = [...(cur ?? []).slice(-59), `${(/* @__PURE__ */ new Date()).toISOString().slice(11, 23)} ${msg}`];
      await chrome.storage.local.set({ [key]: next });
    } catch {
    }
  }
  async function readBlockedHosts() {
    const stored = await chrome.storage.local.get(LOCAL_KEYS.blockedHosts);
    return new Set(stored[LOCAL_KEYS.blockedHosts] ?? []);
  }
  async function isEnforceable(host) {
    const cached = enforcement.get(host);
    if (cached !== void 0) {
      void diag2(`isEnforceable(${host}) \u2192 \u7F13\u5B58 ${cached}`);
      return cached;
    }
    const blocked = await readBlockedHosts();
    if (blocked.has(host)) {
      enforcement.set(host, false);
      void diag2(`isEnforceable(${host}) \u2192 false\uFF08\u672C\u5730\u505C\u7528\u540D\u5355\uFF09`);
      return false;
    }
    let granted = false;
    try {
      granted = await chrome.permissions.contains({ origins: [`*://${host}/*`] });
    } catch {
      granted = false;
    }
    if (!granted) {
      try {
        granted = await chrome.permissions.contains({ origins: ["*://*/*"] });
      } catch {
        granted = false;
      }
    }
    enforcement.set(host, granted);
    void diag2(`isEnforceable(${host}) \u2192 ${granted}\uFF08permissions.contains \u5B9E\u67E5\uFF09`);
    return granted;
  }
  function invalidateEnforcementCache() {
    enforcement.clear();
  }
  async function readState2() {
    const [bindStored, tokenStored] = await Promise.all([
      chrome.storage.session.get(SESSION_KEYS.parTabBindings),
      chrome.storage.session.get(SESSION_KEYS.parTokens)
    ]);
    bindings2.clear();
    const bindMap = bindStored[SESSION_KEYS.parTabBindings];
    if (bindMap) {
      for (const [tabId, b] of Object.entries(bindMap)) {
        bindings2.set(Number(tabId), b);
      }
    }
    tokens.clear();
    const tokenMap = tokenStored[SESSION_KEYS.parTokens];
    if (tokenMap) {
      for (const [id, t] of Object.entries(tokenMap)) {
        tokens.set(id, t);
      }
    }
  }
  async function persistBindings2() {
    const map = {};
    for (const [tabId, b] of bindings2) {
      map[String(tabId)] = b;
    }
    await chrome.storage.session.set({ [SESSION_KEYS.parTabBindings]: map });
  }
  async function persistTokens() {
    const map = {};
    for (const [id, t] of tokens) {
      map[id] = t;
    }
    await chrome.storage.session.set({ [SESSION_KEYS.parTokens]: map });
  }
  async function applyTitle2(tabId, tabName) {
    await setTabTitle(tabId, tabName);
    try {
      await chrome.tabs.sendMessage(tabId, { type: CONTENT_MESSAGE.setTitle, alias: tabName });
    } catch {
    }
  }
  async function setPendingAutoLogin2(tabId, username, password) {
    await chrome.storage.session.set({
      [`${SESSION_KEYS.pendingAutoLogins}:${tabId}`]: { username, password, at: Date.now() }
    });
  }
  function boundTabsOf(accountId) {
    const out = [];
    for (const [tabId, b] of bindings2) {
      if (b.accountId === accountId) {
        out.push(tabId);
      }
    }
    return out;
  }
  async function captureToken(accountId, host, rawToken) {
    const token = rawToken.startsWith("Bearer ") ? rawToken.slice(7).trim() : rawToken.trim();
    if (!token || !/^[\w-]+\.[\w-]+\.[\w-]*$/.test(token)) {
      return;
    }
    const snap = tokens.get(accountId) ?? {};
    if (snap.token === token) {
      return;
    }
    const isFirstCapture = !snap.token;
    snap.token = token;
    tokens.set(accountId, snap);
    await persistTokens();
    if (isFirstCapture) {
      await snapshotLoginCookies(accountId, host);
    }
    await syncAccountRules(accountId, host);
  }
  var IDENTITY_COOKIE_BLACKLIST = /* @__PURE__ */ new Set(["__auth_token__", "__auth_user__", "__device_fp__"]);
  async function snapshotLoginCookies(accountId, host) {
    const snap = tokens.get(accountId);
    if (!snap?.token) {
      return;
    }
    try {
      const list = await chrome.cookies.getAll({ url: `https://${host}/` });
      const before = list.length;
      snap.cookies = list.filter((c) => !IDENTITY_COOKIE_BLACKLIST.has(c.name)).map((c) => ({ name: c.name, value: c.value }));
      tokens.set(accountId, snap);
      await persistTokens();
      void diag2(`snapshotLoginCookies(${accountId}) \u5FEB\u7167 ${snap.cookies.length} \u6761\uFF08jar \u5171 ${before}\uFF0C\u5254\u8EAB\u4EFD\u7C7B ${before - snap.cookies.length}\uFF09`);
    } catch (e) {
      void diag2(`snapshotLoginCookies(${accountId}) \u5931\u8D25\uFF1A${e instanceof Error ? e.message : String(e)}`);
    }
  }
  function cookieHeaderOf(accountId) {
    const cs = tokens.get(accountId)?.cookies;
    if (!cs || !cs.length) {
      return null;
    }
    const filtered = cs.filter((c) => !IDENTITY_COOKIE_BLACKLIST.has(c.name));
    if (!filtered.length) {
      return null;
    }
    return filtered.map((c) => `${c.name}=${c.value}`).join("; ");
  }
  async function syncAccountRules(accountId, host) {
    const bound = boundTabsOf(accountId);
    void diag2(`syncAccountRules(${accountId}) \u7ED1\u5B9A\u6807\u7B7E=${bound.join(",") || "\u65E0"}`);
    if (!await isEnforceable(host)) {
      void diag2(`syncAccountRules(${accountId}) \u8DF3\u8FC7\uFF1A\u6388\u6743\u4E0D\u53EF\u6267\u884C`);
      return;
    }
    const token = tokens.get(accountId)?.token ?? null;
    const cookieHeader = cookieHeaderOf(accountId);
    try {
      await Promise.all(bound.map((tabId) => tabRules.applyBinding(host, tabId, token, cookieHeader)));
      void diag2(
        `syncAccountRules(${accountId}) \u5B8C\u6210\uFF1AapplyBinding \xD7${bound.length}\uFF08token=${token ? "\u6709" : "\u65E0"} cookie=${cookieHeader ? `${cookieHeader.length}B` : "\u5265\u79BB"}\uFF09`
      );
    } catch (e) {
      void diag2(`syncAccountRules(${accountId}) \u5F02\u5E38\uFF1A${e instanceof Error ? e.message : String(e)}`);
      throw e;
    }
  }
  var parallelSession = {
    /** 打开（或新建）账号标签页并完成绑定 */
    async open(accountId, forceNewTab = false) {
      void diag2(`open(${accountId}) \u5165\u53E3`);
      const account = await parallelStore.get(accountId);
      let tabId = null;
      if (!forceNewTab) {
        const existing = boundTabsOf(accountId)[0];
        if (existing !== void 0 && await tabStillAlive(existing)) {
          tabId = existing;
        }
      }
      if (tabId === null) {
        const hasToken = Boolean(tokens.get(accountId)?.token);
        const url = `https://${account.siteHost}${hasToken ? "/" : "/login"}`;
        const tab = await chrome.tabs.create({ url });
        tabId = tab.id;
        void diag2(`open(${accountId}) \u65B0\u5EFA tab=${tabId} url=${url}`);
      } else {
        await chrome.tabs.update(tabId, { active: true });
        void diag2(`open(${accountId}) \u590D\u7528 tab=${tabId}`);
      }
      bindings2.set(tabId, { accountId: account.id, host: account.siteHost });
      await persistBindings2();
      void diag2(`open(${accountId}) \u7ED1\u5B9A\u5DF2\u6301\u4E45\u5316`);
      if (account.credentials) {
        try {
          const creds = await credentials.decryptCredentials(account.credentials);
          await setPendingAutoLogin2(tabId, creds.username, creds.password);
          void diag2(`open(${accountId}) \u51ED\u8BC1\u89E3\u5BC6\u5E76\u4E0B\u53D1\u5F85\u767B\u5F55`);
        } catch (e) {
          void diag2(`open(${accountId}) \u51ED\u8BC1\u89E3\u5BC6\u5931\u8D25\uFF1A${e instanceof Error ? e.message : String(e)}`);
        }
      } else {
        void diag2(`open(${accountId}) \u65E0\u51ED\u8BC1\u5B57\u6BB5`);
      }
      await pushBind(tabId);
      void diag2(`open(${accountId}) pushBind \u5B8C\u6210`);
      await applyTitle2(tabId, account.tabName);
      await syncAccountRules(account.id, account.siteHost);
      void diag2(`open(${accountId}) \u5B8C\u6210 tabId=${tabId}`);
      return { tabId, reused: false };
    },
    /** 解绑单个标签页（不动账号数据） */
    async unbindTab(tabId) {
      if (bindings2.delete(tabId)) {
        await persistBindings2();
      }
      await tabRules.clearTab(tabId);
      try {
        await pushDown(tabId, { op: "unbound" });
      } catch {
      }
    },
    /** 删除账号：关闭其全部绑定标签页、摘除规则、清 token */
    async deleteAccount(accountId) {
      const tabs = boundTabsOf(accountId);
      for (const tabId of tabs) {
        await this.unbindTab(tabId);
      }
      if (tabs.length) {
        await chrome.tabs.remove(tabs).catch(() => void 0);
      }
      tokens.delete(accountId);
      await persistTokens();
      await parallelStore.delete(accountId);
    },
    /** ISOLATED 桥上行消息入口 */
    async handleBridge(payload, tabId) {
      if (payload.op === "hello") {
        if (tabId !== void 0) {
          const binding2 = bindings2.get(tabId);
          if (binding2) {
            return buildBindPayload(binding2.accountId, tabId);
          }
        }
        return { op: "unbound" };
      }
      if (tabId === void 0) {
        return void 0;
      }
      const binding = bindings2.get(tabId);
      if (!binding) {
        return void 0;
      }
      if (payload.op === "storageWrite") {
        const snap = tokens.get(binding.accountId) ?? {};
        if (payload.key === "__auth_token__") {
          if (payload.value === null) {
            delete snap.token;
            delete snap.cookies;
            tokens.set(binding.accountId, snap);
            await persistTokens();
            await syncAccountRules(binding.accountId, binding.host);
          } else {
            await captureToken(binding.accountId, binding.host, payload.value);
          }
        } else if (payload.key === "__auth_user__") {
          snap.authUser = payload.value ?? void 0;
          tokens.set(binding.accountId, snap);
          await persistTokens();
        } else if (payload.key === "__device_fp__") {
          snap.deviceFp = payload.value ?? void 0;
          tokens.set(binding.accountId, snap);
          await persistTokens();
        }
        return void 0;
      }
      if (payload.op === "authHeader") {
        await captureToken(binding.accountId, binding.host, payload.value);
        return void 0;
      }
      return void 0;
    },
    /** UI 列表：返回实时状态（绑定标签页 / token / 网络平面健康） */
    statusOf(accountId) {
      const tabs = boundTabsOf(accountId);
      const host = tabs.length ? bindings2.get(tabs[0])?.host : void 0;
      let enforcementOff = false;
      if (host) {
        enforcementOff = !enforcement.get(host);
      } else {
        void parallelStore.get(accountId).then((a) => isEnforceable(a.siteHost)).catch(() => false);
      }
      return { tabIds: tabs, hasToken: Boolean(tokens.get(accountId)?.token), enforcementOff };
    },
    /** 账号改名后刷新所有绑定标签页标题 */
    async refreshTitle(accountId) {
      const account = await parallelStore.get(accountId);
      await Promise.all(boundTabsOf(accountId).map((t) => applyTitle2(t, account.tabName)));
    },
    /** 诊断用内部状态快照（经 ql.diag 消息暴露给台架） */
    debugState() {
      return {
        bindings: Array.from(bindings2.entries()).map(([t, b]) => ({ t, accountId: b.accountId, host: b.host })),
        tokenAccounts: Array.from(tokens.keys()),
        enforcement: Array.from(enforcement.entries()).map(([h, ok2]) => `${h}=${ok2}`)
      };
    },
    /* ------- 导航事件钩子（由 registerParallelHandlers 驱动） ------- */
    /** 标签页导航开始：重新推绑定种子与标题（SPA/整页刷新都会重置） */
    async onNavigation(tabId) {
      const binding = bindings2.get(tabId);
      if (!binding) {
        return;
      }
      const account = await parallelStore.get(binding.accountId).catch(() => void 0);
      if (!account) {
        return;
      }
      await pushBind(tabId);
      await applyTitle2(tabId, account.tabName);
    },
    /** SW 冷启动恢复：绑定表 + token/Cookie 快照 → 重建内存态与规则（授权健康门控） */
    async restore() {
      void diag2("parallelSession.restore \u5F00\u59CB");
      await readState2();
      enforcement.clear();
      const persisted = /* @__PURE__ */ new Map();
      for (const [tabId, b] of bindings2) {
        if (await isEnforceable(b.host)) {
          persisted.set(tabId, {
            host: b.host,
            token: tokens.get(b.accountId)?.token ?? null,
            cookie: cookieHeaderOf(b.accountId)
          });
        }
      }
      await tabRules.restore(persisted);
      void diag2(`parallelSession.restore \u5B8C\u6210 persisted=${persisted.size}`);
    },
    async handleTabRemoved(tabId) {
      if (bindings2.has(tabId)) {
        await this.unbindTab(tabId);
      }
    }
  };
  async function tabStillAlive(tabId) {
    try {
      await chrome.tabs.get(tabId);
      return true;
    } catch {
      return false;
    }
  }
  function buildBindPayload(accountId, tabId) {
    const snap = tokens.get(accountId);
    const seed = {};
    if (snap?.token) {
      seed["__auth_token__"] = snap.token;
    }
    if (snap?.authUser) {
      seed["__auth_user__"] = snap.authUser;
    }
    if (snap?.deviceFp) {
      seed["__device_fp__"] = snap.deviceFp;
    }
    return { op: "bind", accountId, tabId, seed };
  }
  async function pushBind(tabId) {
    const binding = bindings2.get(tabId);
    if (!binding) {
      return;
    }
    await pushDown(tabId, buildBindPayload(binding.accountId, tabId));
  }
  async function pushDown(tabId, payload) {
    try {
      await chrome.tabs.sendMessage(tabId, { type: CONTENT_MESSAGE.bridgeDown, payload });
    } catch {
    }
  }
  function registerParallelHandlers() {
    void parallelSession.restore();
    chrome.runtime.onStartup?.addListener(() => {
      void parallelSession.restore();
    });
    chrome.tabs.onRemoved.addListener((tabId) => {
      void parallelSession.handleTabRemoved(tabId);
    });
    chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
      if (changeInfo.status === "loading") {
        void parallelSession.onNavigation(tabId);
      }
    });
    void cleanupStaleBindings();
  }
  async function cleanupStaleBindings() {
    for (const tabId of Array.from(bindings2.keys())) {
      const alive = await tabStillAlive(tabId);
      if (!alive) {
        await parallelSession.handleTabRemoved(tabId);
      }
    }
  }

  // packages/extension/src/background/service-worker.ts
  function ok(data) {
    return { ok: true, data };
  }
  function fail(error) {
    return { ok: false, error: error instanceof Error ? error.message : String(error) };
  }
  async function tryRun(fn) {
    try {
      return ok(await fn());
    } catch (e) {
      return fail(e);
    }
  }
  async function dispatch(req) {
    switch (req.kind) {
      case "session.list":
        return { kind: "session.list", result: await tryRun(() => sessionManager.list()) };
      case "session.update": {
        const r = await tryRun(() => sessionManager.update(req.id, req.patch));
        if (r.ok) {
          accountRegistry.invalidate(req.id);
        }
        return { kind: "session.update", result: r };
      }
      case "session.delete": {
        const r = await tryRun(() => sessionManager.delete(req.id));
        accountRegistry.invalidate(req.id);
        return { kind: "session.delete", result: r };
      }
      case "session.open": {
        const r = await tryRun(async () => {
          const session = await sessionManager.getOrThrow(req.id);
          let creds;
          if (session.credentials) {
            creds = await credentials.decryptCredentials(session.credentials);
          }
          const { tabId } = await navigation.switchAccount(session, creds);
          return { tabId };
        });
        return { kind: "session.open", result: r };
      }
      case "session.openOrCreate": {
        const r = await tryRun(async () => {
          const all = await sessionManager.list();
          const byHost = all.filter((s) => s.siteHost === req.host);
          let session;
          if (req.accountAlias) {
            session = byHost.find((s) => (s.accountAlias || s.name) === req.accountAlias);
          } else {
            session = byHost.sort((a, b) => b.updatedAt - a.updatedAt)[0];
          }
          if (!session) {
            session = await sessionManager.create({
              name: req.accountAlias || req.username || req.host,
              accountAlias: req.accountAlias || req.username || req.host,
              siteHost: req.host
            });
          }
          let creds;
          if (req.username && req.password) {
            await sessionManager.updateCredentials(
              session.id,
              await credentials.encryptCredentials(req.username, req.password)
            );
            creds = { username: req.username, password: req.password };
          } else if (session.credentials) {
            creds = await credentials.decryptCredentials(session.credentials);
          }
          const { tabId, reused } = await navigation.switchAccount(session, creds);
          return { tabId, sessionId: session.id, reused };
        });
        return { kind: "session.openOrCreate", result: r };
      }
      case "site.grants.list":
        return { kind: "site.grants.list", result: { ok: true, data: [] } };
      case "site.grant.add":
        return { kind: "site.grant.add", result: fail("v2.4 \u8D77\u6539\u4E3A\u5728\u5F39\u7A97/\u5E76\u884C\u9875\u76F4\u63A5\u6388\u6743") };
      case "par.grantChanged": {
        invalidateEnforcementCache();
        return { kind: "par.grantChanged", result: ok(true) };
      }
      case "ql.diag": {
        const r = await tryRun(async () => {
          const out = {};
          try {
            await chrome.storage.local.set({ __qt: Date.now() });
            const v = await chrome.storage.local.get("__qt");
            out.storageWrite = "OK";
            out.storageRead = Boolean(v["__qt"]);
          } catch (e) {
            out.storageErr = e instanceof Error ? e.message : String(e);
          }
          try {
            out.manifestVersion = chrome.runtime.getManifest().version;
          } catch (e) {
            out.manifestErr = e instanceof Error ? e.message : String(e);
          }
          try {
            const rules = await chrome.declarativeNetRequest.getSessionRules();
            out.sessionRuleCount = rules.length;
          } catch (e) {
            out.rulesErr = e instanceof Error ? e.message : String(e);
          }
          try {
            await chrome.declarativeNetRequest.updateSessionRules({
              addRules: [
                {
                  id: 777001,
                  priority: 1,
                  action: {
                    type: "modifyHeaders",
                    requestHeaders: [{ header: "Cookie", operation: "remove" }]
                  },
                  condition: {
                    resourceTypes: ["main_frame"],
                    requestDomains: ["tonbridge-config.aksoegmp.com"],
                    tabIds: [999999]
                  }
                }
              ]
            });
            await chrome.declarativeNetRequest.updateSessionRules({ removeRuleIds: [777001] });
            out.dnrInSw = "OK";
          } catch (e) {
            out.dnrInSwErr = e instanceof Error ? e.message : String(e);
          }
          out.parallel = parallelSession.debugState();
          out.tabRules = tabRules.debugState();
          return out;
        });
        return { kind: "ql.diag", result: r };
      }
      /* ---------------- 浏览器并行账号（纯扩展模式） ---------------- */
      case "par.list": {
        const r = await tryRun(
          async () => (await parallelStore.list()).map((a) => ({
            ...a,
            ...parallelSession.statusOf(a.id),
            password: Boolean(a.credentials)
          }))
        );
        return { kind: "par.list", result: r };
      }
      case "par.create": {
        const r = await tryRun(async () => {
          const account = await parallelStore.create({
            siteHost: req.siteHost,
            tabName: req.tabName,
            username: req.username,
            password: req.password
          });
          if (req.open) {
            await parallelSession.open(account.id, false);
          }
          return account;
        });
        return { kind: "par.create", result: r };
      }
      case "par.update": {
        const r = await tryRun(async () => {
          const account = await parallelStore.updateTabName(req.id, req.patch.tabName ?? "");
          await parallelSession.refreshTitle(req.id);
          return account;
        });
        return { kind: "par.update", result: r };
      }
      case "par.delete": {
        const r = await tryRun(() => parallelSession.deleteAccount(req.id));
        return { kind: "par.delete", result: r };
      }
      case "par.open": {
        const r = await tryRun(() => parallelSession.open(req.id, req.forceNewTab === true));
        return { kind: "par.open", result: r };
      }
      case "wheel.toggle": {
        const r = await tryRun(async () => {
          await toggleAccountWheel();
          return { opened: wheelWinId !== null };
        });
        return { kind: "wheel.toggle", result: r };
      }
    }
  }
  chrome.runtime.onMessage.addListener((req, sender, sendResponse) => {
    if (req && typeof req === "object" && req.type === CONTENT_MESSAGE.bridgeUp) {
      const payload = req.payload;
      void parallelSession.handleBridge(payload, sender.tab?.id).then(sendResponse);
      return true;
    }
    if (req && typeof req === "object" && req.type === CONTENT_MESSAGE.autoLoginRequest) {
      const tabId = sender.tab?.id;
      if (tabId === void 0) {
        sendResponse(null);
        return true;
      }
      void navigation.getPendingAutoLogin(tabId).then((creds) => sendResponse(creds));
      return true;
    }
    void dispatch(req).then(sendResponse);
    return true;
  });
  var WHEEL_PAGE = "ui/wheel/wheel.html";
  var WHEEL_W = 420;
  var WHEEL_H = 480;
  var WHEEL_OVERLAY_FILE = "content/wheel-overlay.js";
  var wheelWinId = null;
  var lastToggleAt = 0;
  chrome.windows.onRemoved.addListener((winId) => {
    if (winId === wheelWinId) {
      wheelWinId = null;
    }
  });
  async function toggleAccountWheel() {
    const now = Date.now();
    if (now - lastToggleAt < 300) {
      return;
    }
    lastToggleAt = now;
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    try {
      if (tab?.id && tab.url && /^https?:/i.test(tab.url)) {
        await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          files: [WHEEL_OVERLAY_FILE],
          world: "ISOLATED"
        });
        return;
      }
    } catch {
    }
    if (wheelWinId !== null) {
      try {
        await chrome.windows.get(wheelWinId);
      } catch {
        wheelWinId = null;
      }
      if (wheelWinId !== null) {
        await chrome.windows.remove(wheelWinId).catch(() => void 0);
        wheelWinId = null;
        return;
      }
    }
    const current = tab ? await chrome.windows.get(tab.windowId).catch(() => void 0) : void 0;
    const left = current && typeof current.left === "number" ? Math.max(0, current.left + Math.max(0, (current.width ?? 900) - WHEEL_W >> 1)) : void 0;
    const top = current && typeof current.top === "number" ? Math.max(0, current.top + Math.max(0, (current.height ?? 700) - WHEEL_H >> 1)) : void 0;
    try {
      const win = await chrome.windows.create({
        url: chrome.runtime.getURL(WHEEL_PAGE),
        type: "popup",
        width: WHEEL_W,
        height: WHEEL_H,
        left,
        top
      });
      wheelWinId = win.id ?? null;
      return;
    } catch {
    }
    await chrome.tabs.create({ url: chrome.runtime.getURL(WHEEL_PAGE) });
  }
  chrome.commands.onCommand.addListener((command) => {
    if (command === "quick-wheel") {
      void flashBadge("\u2192");
      void toggleAccountWheel();
    }
  });
  async function flashBadge(text) {
    try {
      await chrome.action.setBadgeBackgroundColor({ color: "#1E6FFF" });
      await chrome.action.setBadgeText({ text });
      window.setTimeout(() => {
        void chrome.action.setBadgeText({ text: "" });
      }, 1200);
    } catch {
    }
  }
  registerNavigationHandlers();
  registerParallelHandlers();
  void flashBadge(`v${EXT_VERSION.split(".").slice(0, 2).join(".")}`).finally(() => {
  });
})();

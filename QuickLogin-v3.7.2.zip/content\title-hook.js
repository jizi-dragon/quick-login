"use strict";
(() => {
  // packages/extension/src/shared/constants.ts
  var CONTENT_MESSAGE = {
    setTitle: "sb:setTitle",
    autoLogin: "sb:autoLogin",
    autoLoginRequest: "sb:autoLoginRequest",
    /** ISOLATED 桥 → background（双向通路的上行） */
    bridgeUp: "ql:bridgeUp",
    /** background → ISOLATED 桥（下行） */
    bridgeDown: "ql:bridgeDown"
  };

  // packages/extension/src/content/title-hook.ts
  var alias = "";
  function apply() {
    if (alias && document.title !== alias) {
      document.title = alias;
    }
  }
  function startTitleHook() {
    const observer = new MutationObserver(() => apply());
    observer.observe(document.documentElement, {
      childList: true,
      subtree: true,
      characterData: true
    });
    apply();
  }
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && typeof msg === "object" && msg.type === CONTENT_MESSAGE.setTitle) {
      alias = msg.alias ?? "";
      apply();
    }
  });
  startTitleHook();
})();

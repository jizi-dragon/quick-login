"use strict";
(() => {
  // packages/extension/src/shared/constants.ts
  var EXT_VERSION = "3.7.2";

  // packages/extension/src/ui/popup/popup.ts
  document.getElementById("ext-version").textContent = `QuickLogin v${EXT_VERSION}`;
  var grantBtn = document.getElementById("grant-site");
  var grantHint = document.getElementById("grant-hint");
  function openParallelPage() {
    chrome.tabs.create({ url: chrome.runtime.getURL("ui/parallel/parallel.html") });
    window.close();
  }
  async function currentTabHost() {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url) {
      return null;
    }
    try {
      const u = new URL(tab.url);
      return u.protocol === "http:" || u.protocol === "https:" ? u.host : null;
    } catch {
      return null;
    }
  }
  async function refreshGrantState() {
    const host = await currentTabHost();
    if (!host) {
      grantBtn.disabled = true;
      grantHint.textContent = "\u5F53\u524D\u6807\u7B7E\u9875\u4E0D\u662F http/https \u7AD9\u70B9\u3002";
      return;
    }
    const granted = await chrome.permissions.contains({ origins: [`*://${host}/*`] });
    grantBtn.textContent = granted ? `\u5DF2\u6388\u6743 ${host}` : `\u6388\u6743\u5F53\u524D\u7AD9\u70B9\uFF08${host}\uFF09`;
    grantBtn.classList.toggle("granted", granted);
    grantHint.textContent = granted ? "\u8BE5\u7AD9\u70B9\u5DF2\u53EF\u5E76\u884C\u591A\u5F00\u3002\u53BB\u5E76\u884C\u7BA1\u7406\u9875\u6DFB\u52A0\u8D26\u53F7\u5373\u53EF\u3002" : "\u6388\u6743\u540E\u6269\u5C55\u624D\u80FD\u4E3A\u8BE5\u7AD9\u70B9\u6539\u5199\u9274\u6743\u5934\u5E76\u9694\u79BB\u5B58\u50A8\u3002";
  }
  grantBtn.addEventListener("click", () => {
    void (async () => {
      const host = await currentTabHost();
      if (!host) {
        return;
      }
      const ok = await chrome.permissions.request({ origins: [`*://${host}/*`] }).catch(() => false);
      if (!ok) {
        return;
      }
      await refreshGrantState();
      openParallelPage();
    })();
  });
  document.getElementById("open-parallel").addEventListener("click", openParallelPage);
  document.getElementById("open-wheel").addEventListener("click", () => {
    void chrome.runtime.sendMessage({ kind: "wheel.toggle" }).then(() => window.close()).catch(() => window.close());
  });
  void refreshGrantState();
})();

"use strict";
(() => {
  // packages/extension/src/shared/constants.ts
  var CONTENT_MESSAGE = {
    setTitle: "sb:setTitle",
    autoLogin: "sb:autoLogin",
    autoLoginRequest: "sb:autoLoginRequest",
    /** ISOLATED 桥 → background（双向通路的上行） */
    bridgeUp: "ql:bridgeUp",
    /** background → ISOLATED 桥（下行） */
    bridgeDown: "ql:bridgeDown"
  };

  // packages/extension/src/content/auto-login.ts
  var credentials = null;
  function isTopFrame() {
    return window === window.top;
  }
  function setValue(el, value, win) {
    const realm = win;
    const setter = Object.getOwnPropertyDescriptor(realm.HTMLInputElement.prototype, "value")?.set;
    if (setter) {
      setter.call(el, value);
    } else {
      el.value = value;
    }
    el.dispatchEvent(new realm.Event("input", { bubbles: true }));
    el.dispatchEvent(new realm.Event("change", { bubbles: true }));
  }
  function fillUsername() {
    const field = document.querySelector('input[placeholder="\u8BF7\u8F93\u5165\u7528\u6237\u540D"]') || document.querySelector('input[type="text"]');
    if (field && credentials) {
      setValue(field, credentials.username, window);
    }
    return field;
  }
  function fillPasswordInIframes() {
    const iframes = document.querySelectorAll("iframe");
    for (const iframe of Array.from(iframes)) {
      try {
        const doc = iframe.contentDocument;
        const win = iframe.contentWindow;
        if (!doc || !win) {
          continue;
        }
        const field = doc.querySelector('input[type="password"]') || doc.querySelector('input[placeholder*="\u5BC6\u7801"]') || doc.querySelector('input[placeholder*="password"]');
        if (field && credentials) {
          setValue(field, credentials.password, win);
        }
        return field;
      } catch {
      }
    }
    return null;
  }
  function checkAgreement() {
    const box = document.getElementById("privacyChecked") || Array.from(document.querySelectorAll('input[type="checkbox"]')).find(
      (el) => /同意|agree/i.test(`${el.name || ""} ${el.ariaLabel || ""} ${el.labels?.[0]?.textContent || ""}`)
    );
    if (box && !box.checked) {
      box.click();
    }
  }
  function findSubmit() {
    const buttons = Array.from(document.querySelectorAll("button"));
    return buttons.find((b) => /登录|登\s*录|login|submit/i.test(b.textContent || "")) || null;
  }
  function runTopFrameFlow() {
    let submitted = false;
    const deadline = Date.now() + 2e4;
    const attempt = () => {
      if (submitted || !credentials) {
        return;
      }
      if (Date.now() > deadline) {
        window.clearInterval(timer);
        return;
      }
      const usernameField = fillUsername();
      const passwordField = fillPasswordInIframes();
      checkAgreement();
      const submit = findSubmit();
      if (submit && usernameField && passwordField) {
        window.setTimeout(() => {
          if (!submitted) {
            submit.click();
            submitted = true;
            window.clearInterval(timer);
          }
        }, 400);
      }
    };
    const timer = window.setInterval(attempt, 800);
    attempt();
  }
  function runIframeFlow() {
    if (!credentials) {
      return;
    }
    const field = document.querySelector('input[type="password"]') || document.querySelector('input[placeholder*="\u5BC6\u7801"]') || document.querySelector('input[placeholder*="password"]');
    if (field) {
      setValue(field, credentials.password, window);
    }
  }
  function start() {
    if (!credentials) {
      return;
    }
    if (isTopFrame()) {
      runTopFrameFlow();
    } else {
      runIframeFlow();
    }
  }
  async function requestCredentials(attempt = 0) {
    if (credentials) {
      return;
    }
    try {
      const res = await chrome.runtime.sendMessage({ type: CONTENT_MESSAGE.autoLoginRequest });
      if (res && typeof res === "object" && typeof res.username === "string" && typeof res.password === "string") {
        credentials = { username: res.username, password: res.password };
        start();
      }
    } catch {
      if (attempt < 3) {
        window.setTimeout(() => void requestCredentials(attempt + 1), 500);
      }
    }
  }
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg && typeof msg === "object" && msg.type === CONTENT_MESSAGE.autoLogin && typeof msg.username === "string" && typeof msg.password === "string") {
      credentials = {
        username: msg.username,
        password: msg.password
      };
      start();
    }
  });
  void requestCredentials();
})();

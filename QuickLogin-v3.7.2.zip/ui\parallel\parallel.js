"use strict";
(() => {
  // packages/extension/src/shared/constants.ts
  var EXT_VERSION = "3.7.2";
  var LOCAL_KEYS = {
    siteGrants: "sb:siteGrants",
    /** 手动停用的站点（Chrome 拒绝回收授权时本地封锁，不再对其安装改头规则） */
    blockedHosts: "ql:blockedHosts"
  };

  // packages/extension/src/ui/send.ts
  function send(req) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(req, resolve);
    });
  }

  // packages/extension/src/ui/parallel/parallel.ts
  var verChip = document.getElementById("ver-chip");
  verChip.textContent = `v${EXT_VERSION} \xB7 \u7EAF\u6D4F\u89C8\u5668\u5E76\u884C`;
  var browserListEl = document.getElementById("browser-list");
  var parForm = document.getElementById("par-form");
  var pHostSelect = document.getElementById("p-host");
  var pTabName = document.getElementById("p-tabname");
  var pUsername = document.getElementById("p-username");
  var pPassword = document.getElementById("p-password");
  var PREFERRED_HOST = "tonbridge-config.aksoegmp.com";
  var LAST_HOST_KEY = "ql:lastParHost";
  var browserAccounts = [];
  async function loadBrowserAccounts() {
    const res = await send({ kind: "par.list" });
    browserAccounts = res.kind === "par.list" && res.result.ok ? res.result.data : [];
    renderBrowserAccounts();
    renderSites(grantedHosts);
  }
  function badgeOf(a) {
    if (a.enforcementOff) {
      return { cls: "login_failed", text: "\u672A\u6388\u6743 \xB7 \u5DF2\u6682\u505C" };
    }
    if (a.hasToken && a.tabIds.length > 0) {
      return { cls: "online", text: `\u5728\u7EBF \xD7${a.tabIds.length}` };
    }
    if (a.tabIds.length > 0) {
      return { cls: "starting", text: "\u5F85\u767B\u5F55" };
    }
    return { cls: "offline", text: "\u79BB\u7EBF" };
  }
  function renderBrowserAccounts() {
    browserListEl.innerHTML = "";
    if (!browserAccounts.length) {
      const li = document.createElement("li");
      li.className = "account-item";
      li.textContent = "\u6682\u65E0\u5E76\u884C\u8D26\u53F7\u3002\u586B\u5199\u4E0A\u65B9\u8868\u5355\u6DFB\u52A0\uFF0C\u5BC6\u7801\u5C06\u4EE5 AES-GCM \u52A0\u5BC6\u5B58\u653E\u5728\u672C\u673A\u3002";
      browserListEl.appendChild(li);
      return;
    }
    for (const a of browserAccounts) {
      const li = document.createElement("li");
      li.className = "card account-item par-account";
      li.style.borderLeft = `3px solid ${a.color}`;
      const meta = document.createElement("div");
      meta.className = "meta";
      const alias = document.createElement("div");
      alias.className = "alias";
      alias.textContent = a.tabName || a.username;
      const sub = document.createElement("div");
      sub.className = "sub";
      sub.textContent = `${a.username} \xB7 ${a.siteHost}${a.password ? " \xB7 \u5DF2\u5B58\u5BC6\u7801" : ""}`;
      meta.append(alias, sub);
      const badge = document.createElement("span");
      const b = badgeOf(a);
      badge.className = `badge ${b.cls}`;
      badge.textContent = b.text;
      const openBtn = document.createElement("button");
      openBtn.className = "btn-ghost";
      openBtn.textContent = a.tabIds.length ? "\u805A\u7126\u6807\u7B7E\u9875" : "\u6253\u5F00";
      openBtn.addEventListener("click", () => void openAccount(a.id, false));
      const newTabBtn = document.createElement("button");
      newTabBtn.className = "btn-ghost";
      newTabBtn.textContent = "\u65B0\u6807\u7B7E\u9875";
      newTabBtn.addEventListener("click", () => void openAccount(a.id, true));
      const renameBtn = document.createElement("button");
      renameBtn.className = "btn-ghost";
      renameBtn.textContent = "\u6539\u9875\u7B7E\u540D";
      renameBtn.addEventListener("click", () => {
        const next = prompt("\u65B0\u7684\u9875\u7B7E\u540D\uFF08\u8BE5\u8D26\u53F7\u6807\u7B7E\u9875\u7684\u6807\u9898\uFF09", a.tabName || a.username);
        if (next === null) {
          return;
        }
        void (async () => {
          await send({ kind: "par.update", id: a.id, patch: { tabName: next.trim() || a.username } });
          await loadBrowserAccounts();
        })();
      });
      const del = document.createElement("button");
      del.className = "btn-danger";
      del.textContent = "\u5220\u9664";
      del.addEventListener("click", () => {
        if (confirm(`\u5220\u9664\u8D26\u53F7\u300C${a.tabName || a.username}\u300D\uFF1F\u5C06\u540C\u65F6\u5173\u95ED\u5176\u6240\u6709\u5E76\u884C\u6807\u7B7E\u9875\u3002`)) {
          void (async () => {
            await send({ kind: "par.delete", id: a.id });
            await loadBrowserAccounts();
          })();
        }
      });
      li.append(meta, badge, openBtn, newTabBtn, renameBtn, del);
      browserListEl.appendChild(li);
    }
  }
  async function ensureHostPermission(host) {
    try {
      return await chrome.permissions.request({ origins: [`*://${host}/*`] });
    } catch {
      return false;
    }
  }
  async function openAccount(id, forceNewTab) {
    const account = browserAccounts.find((x) => x.id === id);
    if (!account) {
      return;
    }
    if (!await ensureHostPermission(account.siteHost)) {
      alert(`\u9700\u8981\u6388\u6743\u8BBF\u95EE ${account.siteHost} \u624D\u80FD\u6539\u5199\u5176\u8BF7\u6C42\u5934\u3002`);
      return;
    }
    const res = await send({ kind: "par.open", id, forceNewTab });
    if (!res.result.ok) {
      alert(`\u6253\u5F00\u5931\u8D25\uFF1A${res.result.error}`);
      return;
    }
    await loadBrowserAccounts();
  }
  async function createAccount(open) {
    const siteHost = pHostSelect.value;
    if (!siteHost) {
      alert("\u8BF7\u5148\u5728\u4E0B\u65B9\u300C\u7AD9\u70B9\u7BA1\u7406\u300D\u6DFB\u52A0\u5E76\u6388\u6743\u7AD9\u70B9\uFF0C\u7AD9\u70B9\u4E0B\u62C9\u624D\u4F1A\u6709\u53EF\u9009\u9879\u3002");
      return;
    }
    const tabName = pTabName.value.trim();
    const username = pUsername.value.trim();
    const password = pPassword.value;
    if (!username || !password) {
      return;
    }
    const res = await send({ kind: "par.create", siteHost, tabName, username, password, open });
    if (!res.result.ok) {
      alert(`\u6DFB\u52A0\u5931\u8D25\uFF1A${res.result.error}`);
      return;
    }
    await chrome.storage.local.set({ [LAST_HOST_KEY]: siteHost });
    pTabName.value = "";
    pUsername.value = "";
    pPassword.value = "";
    await loadBrowserAccounts();
  }
  parForm.addEventListener("submit", (e) => {
    e.preventDefault();
    void createAccount(true);
  });
  document.getElementById("add-only").addEventListener("click", () => {
    void createAccount(false);
  });
  var siteForm = document.getElementById("site-form");
  var sHost = document.getElementById("s-host");
  var siteListEl = document.getElementById("site-list");
  var grantedHosts = [];
  var blockedHosts = [];
  function originToHost(origin) {
    const m = /^(?:\*|https?):\/\/([^/]+)(?:\/.*)?$/.exec(origin);
    if (!m) {
      return null;
    }
    return m[1] === "*" ? null : m[1];
  }
  function patternOfHost(host) {
    return `*://${host}/*`;
  }
  function countAccountsFor(displayHost) {
    const bare = displayHost.replace(/^\*\./, "");
    return browserAccounts.filter((a) => a.siteHost === displayHost || a.siteHost.endsWith(`.${bare}`)).length;
  }
  async function loadSites() {
    const all = await chrome.permissions.getAll();
    const blockedStored = await chrome.storage.local.get(LOCAL_KEYS.blockedHosts);
    const blocked = new Set(blockedStored[LOCAL_KEYS.blockedHosts] ?? []);
    grantedHosts = Array.from(
      new Set((all.origins ?? []).map(originToHost).filter((h) => h !== null))
    ).sort();
    for (const b of Array.from(blocked)) {
      const still = await chrome.permissions.contains({ origins: [`*://${b}/*`] }).catch(() => false);
      if (!still) {
        blocked.delete(b);
      }
    }
    blockedHosts = Array.from(blocked).sort();
    await chrome.storage.local.set({ [LOCAL_KEYS.blockedHosts]: blockedHosts });
    renderSites(grantedHosts, blockedHosts);
  }
  function renderSites(hosts, blocked = []) {
    siteListEl.innerHTML = "";
    if (!hosts.length && !blocked.length) {
      const li = document.createElement("li");
      li.className = "account-item";
      li.textContent = "\u5C1A\u65E0\u6388\u6743\u7AD9\u70B9\u3002\u7528\u4E0A\u65B9\u8868\u5355\u6DFB\u52A0\uFF0C\u6216\u5728\u76EE\u6807\u7AD9\u6807\u7B7E\u9875\u4E0A\u4F7F\u7528\u5F39\u7A97\u7684\u300C\u6388\u6743\u5F53\u524D\u7AD9\u70B9\u300D\u3002";
      siteListEl.appendChild(li);
      return;
    }
    const seen = /* @__PURE__ */ new Set();
    for (const host of [...hosts, ...blocked]) {
      if (seen.has(host)) {
        continue;
      }
      seen.add(host);
      const isBlocked = !hosts.includes(host) || blocked.includes(host);
      const n = countAccountsFor(host);
      const li = document.createElement("li");
      li.className = "card account-item";
      const meta = document.createElement("div");
      meta.className = "meta";
      const alias = document.createElement("div");
      alias.className = "alias";
      alias.textContent = isBlocked ? `${host}\uFF08\u5DF2\u505C\u7528\uFF09` : host;
      if (isBlocked) {
        alias.style.color = "#C2410C";
      }
      const sub = document.createElement("div");
      sub.className = "sub";
      sub.textContent = isBlocked ? `${n} \u4E2A\u5E76\u884C\u8D26\u53F7 \xB7 \u6539\u5934\u89C4\u5219\u5DF2\u5168\u90E8\u6682\u505C` : n > 0 ? `${n} \u4E2A\u5E76\u884C\u8D26\u53F7` : "\u8BE5\u7AD9\u70B9\u6682\u65E0\u5E76\u884C\u8D26\u53F7\uFF08\u6DFB\u52A0\u8D26\u53F7\u540E\u81EA\u52A8\u66F4\u65B0\uFF09";
      meta.append(alias, sub);
      const actionBtn = document.createElement("button");
      actionBtn.className = isBlocked ? "btn-ghost" : "btn-danger";
      actionBtn.textContent = isBlocked ? "\u6062\u590D\u4F7F\u7528" : "\u79FB\u9664\u6388\u6743";
      actionBtn.addEventListener("click", () => {
        if (isBlocked) {
          void unblockHost(host);
          return;
        }
        if (!confirm(`\u79FB\u9664\u5BF9 ${host} \u7684\u6388\u6743\uFF1F\u8BE5\u7AD9\u70B9\u7684\u9274\u6743\u6539\u5199\u5C06\u7ACB\u5373\u5931\u6548\uFF08\u6D4F\u89C8\u5668\u5185\u7684\u767B\u5F55\u6001\u4E0D\u53D7\u5F71\u54CD\uFF09\u3002`)) {
          return;
        }
        void revokeHost(host);
      });
      li.append(meta, actionBtn);
      siteListEl.appendChild(li);
    }
  }
  async function revokeHost(displayHost) {
    const all = await chrome.permissions.getAll();
    const raws = (all.origins ?? []).filter((o) => originToHost(o) === displayHost);
    const errors = [];
    for (const raw of raws) {
      try {
        const okc = await chrome.permissions.remove({ origins: [raw] });
        if (!okc) {
          errors.push(`\u6D4F\u89C8\u5668\u62D2\u7EDD\u79FB\u9664\uFF1A${raw}`);
        }
      } catch (e) {
        errors.push(`${raw} \u2192 ${e instanceof Error ? e.message : String(e)}`);
      }
    }
    const leftover = ((await chrome.permissions.getAll()).origins ?? []).filter(
      (o) => originToHost(o) === displayHost || o.includes("*://*/*")
    );
    const stillCovers = leftover.length > 0;
    const blockedStored = await chrome.storage.local.get(LOCAL_KEYS.blockedHosts);
    const blocked = new Set(blockedStored[LOCAL_KEYS.blockedHosts] ?? []);
    if (stillCovers) {
      blocked.add(displayHost);
      await chrome.storage.local.set({ [LOCAL_KEYS.blockedHosts]: Array.from(blocked).sort() });
      alert(
        `\u300C${displayHost}\u300D\u5DF2\u5728 QuickLogin \u4E2D\u505C\u7528\uFF08\u6539\u5934\u89C4\u5219\u7ACB\u5373\u5931\u6548\uFF09\u3002

\u6D4F\u89C8\u5668\u5E95\u5C42\u6388\u6743\u672A\u80FD\u56DE\u6536\uFF1A
${errors.join("\n") || "(\u65E0\u660E\u7EC6)"}

\u5982\u9700\u5F7B\u5E95\u56DE\u6536\u6D4F\u89C8\u5668\u5C42\u6743\u9650\uFF1Achrome://extensions \u2192 \u8BE6\u60C5 \u2192 \u7F51\u7AD9\u8BBF\u95EE\u6743\u9650 \u2192 \u624B\u52A8\u6536\u7A84\u3002`
      );
    } else if (blocked.has(displayHost)) {
      blocked.delete(displayHost);
      await chrome.storage.local.set({ [LOCAL_KEYS.blockedHosts]: Array.from(blocked).sort() });
    }
    await send({ kind: "par.grantChanged" });
    await loadSites();
    await fillSiteOptions();
    await loadBrowserAccounts();
  }
  async function unblockHost(host) {
    const stored = await chrome.storage.local.get(LOCAL_KEYS.blockedHosts);
    const blocked = new Set(stored[LOCAL_KEYS.blockedHosts] ?? []);
    blocked.delete(host);
    await chrome.storage.local.set({ [LOCAL_KEYS.blockedHosts]: Array.from(blocked).sort() });
    await send({ kind: "par.grantChanged" });
    await Promise.all([loadSites(), fillSiteOptions(), loadBrowserAccounts()]);
  }
  async function fillSiteOptions() {
    pHostSelect.innerHTML = "";
    if (!grantedHosts.length) {
      const empty = document.createElement("option");
      empty.value = "";
      empty.disabled = true;
      empty.selected = true;
      empty.textContent = "\uFF08\u6682\u65E0\u5DF2\u6388\u6743\u7AD9\u70B9 \u2014\u2014 \u8BF7\u5728\u4E0B\u65B9\u300C\u7AD9\u70B9\u7BA1\u7406\u300D\u6DFB\u52A0\uFF09";
      pHostSelect.append(empty);
      return;
    }
    for (const h of grantedHosts) {
      const opt = document.createElement("option");
      opt.value = h;
      opt.textContent = h;
      pHostSelect.append(opt);
    }
    const stored = await chrome.storage.local.get(LAST_HOST_KEY);
    const last = stored[LAST_HOST_KEY];
    const preferred = last && grantedHosts.includes(last) ? last : grantedHosts.includes(PREFERRED_HOST) ? PREFERRED_HOST : grantedHosts[0];
    pHostSelect.value = preferred;
  }
  siteForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const host = sHost.value.trim().replace(/^https?:\/\//, "").replace(/\/.*$/, "");
    if (!host) {
      return;
    }
    void (async () => {
      const ok = await chrome.permissions.request({ origins: [patternOfHost(host)] }).catch(() => false);
      if (!ok) {
        alert(`\u672A\u5B8C\u6210\u6388\u6743\uFF1A${host}`);
        return;
      }
      sHost.value = "";
      await send({ kind: "par.grantChanged" });
      await loadSites();
      await fillSiteOptions();
    })();
  });
  void (async () => {
    await loadBrowserAccounts();
    await loadSites();
    await fillSiteOptions();
  })();
  setInterval(() => void loadBrowserAccounts(), 3e3);
})();

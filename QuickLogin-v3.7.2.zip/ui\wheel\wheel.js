"use strict";
(() => {
  // packages/extension/src/ui/wheel/wheel.ts
  var wheelEl = document.getElementById("wheel");
  var subEl = document.getElementById("sub");
  var PARALLEL_PAGE = chrome.runtime.getURL("ui/parallel/parallel.html");
  var blurArmed = false;
  window.setTimeout(() => {
    blurArmed = true;
  }, 400);
  window.addEventListener("blur", () => {
    if (blurArmed) {
      window.close();
    }
  });
  void window.focus();
  document.getElementById("close").addEventListener("click", () => window.close());
  async function fetchAccounts() {
    const res = await chrome.runtime.sendMessage({ kind: "par.list" });
    if (!res?.result?.ok || !Array.isArray(res.result.data)) {
      return [];
    }
    return [...res.result.data].sort((a, b) => (b.tabIds?.length ?? 0) - (a.tabIds?.length ?? 0));
  }
  var WHEEL_W = 360;
  var WHEEL_H = 330;
  function render(accounts) {
    wheelEl.innerHTML = "";
    const n = accounts.length;
    if (!n) {
      subEl.textContent = "\u8FD8\u6CA1\u6709\u4EFB\u4F55\u5E76\u884C\u8D26\u53F7";
      const card = document.createElement("div");
      card.className = "empty-card";
      const ico = document.createElement("div");
      ico.className = "empty-ico";
      ico.textContent = "\u{1F5C2}\uFE0F";
      const h = document.createElement("h2");
      h.textContent = "\u6682\u65E0\u5E76\u884C\u8D26\u53F7";
      const p = document.createElement("p");
      p.textContent = "\u6DFB\u52A0\u8D26\u53F7\u5E76\u6388\u6743\u7AD9\u70B9\u540E\uFF0C\u8FD9\u91CC\u5C31\u4F1A\u663E\u793A\u53EF\u5207\u6362\u7684\u8EAB\u4EFD\u3002";
      const go = document.createElement("button");
      go.textContent = "\u53BB\u5E76\u884C\u7BA1\u7406\u9875\u6DFB\u52A0";
      go.addEventListener("click", async () => {
        await chrome.tabs.create({ url: PARALLEL_PAGE });
        window.close();
      });
      card.append(ico, h, p, go);
      wheelEl.append(card);
      requestAnimationFrame(() => requestAnimationFrame(() => wheelEl.classList.add("in")));
      return;
    }
    const onlineCount = accounts.filter((a) => (a.tabIds?.length ?? 0) > 0).length;
    subEl.innerHTML = "";
    const cnt = document.createElement("span");
    cnt.textContent = `${n} \u4E2A\u8D26\u53F7`;
    subEl.append(cnt);
    if (onlineCount > 0) {
      subEl.append(` \xB7 ${onlineCount} \u4E2A\u5728\u7EBF`);
      const dot = document.createElement("i");
      dot.className = "on-dot";
      subEl.prepend(dot);
      wheelEl.classList.add("has-online");
    }
    const dense = n >= 9;
    if (dense) {
      wheelEl.classList.add("dense");
    }
    const rx = n <= 6 ? 134 : n <= 8 ? 138 : 144;
    const ry = n <= 6 ? 110 : n <= 8 ? 116 : 122;
    const cx = WHEEL_W / 2;
    const cy = WHEEL_H / 2;
    const pts = accounts.map((_, i) => {
      const rad = (-90 + 360 * i / n) * Math.PI / 180;
      return { x: Math.cos(rad) * rx, y: Math.sin(rad) * ry };
    });
    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    svg.setAttribute("class", "links");
    svg.setAttribute("viewBox", `0 0 ${WHEEL_W} ${WHEEL_H}`);
    for (let i = 0; i < n; i++) {
      const line = document.createElementNS("http://www.w3.org/2000/svg", "line");
      line.setAttribute("x1", String(cx));
      line.setAttribute("y1", String(cy));
      line.setAttribute("x2", String(cx + pts[i].x));
      line.setAttribute("y2", String(cy + pts[i].y));
      line.style.setProperty("--d", `${0.12 + i * 0.04}s`);
      svg.append(line);
    }
    wheelEl.append(svg);
    for (let i = 0; i < n; i++) {
      const a = accounts[i];
      const node = document.createElement("button");
      node.type = "button";
      node.className = "node";
      node.style.setProperty("--x", `${pts[i].x}px`);
      node.style.setProperty("--y", `${pts[i].y}px`);
      node.style.setProperty("--d", `${0.12 + i * 0.04}s`);
      const online = (a.tabIds?.length ?? 0) > 0;
      const ring = online ? "#22C55E" : a.color || "#1E6FFF";
      const avatar = document.createElement("div");
      avatar.className = "avatar";
      avatar.style.setProperty("--ring", ring);
      avatar.textContent = (a.tabName || a.username).trim().charAt(0).toUpperCase() || "?";
      const dot = document.createElement("i");
      dot.className = online ? "dot on" : "dot";
      avatar.append(dot);
      const label = document.createElement("div");
      label.className = "label";
      if (i < 9) {
        const num = document.createElement("b");
        num.textContent = String(i + 1);
        label.append(num);
      }
      label.append(a.tabName || a.username);
      node.append(avatar, label);
      node.title = a.username === a.tabName || !a.username ? a.tabName || a.username : `${a.tabName || a.username}\uFF08${a.username}\uFF09`;
      node.addEventListener("click", () => void pick(a.id));
      wheelEl.append(node);
    }
    const hub = document.createElement("div");
    hub.className = "hub";
    const inner = document.createElement("div");
    inner.className = "hub-inner";
    const glyph = document.createElement("div");
    glyph.className = "hub-glyph";
    glyph.textContent = "Q";
    const b = document.createElement("b");
    b.textContent = "\u9009\u62E9\u8D26\u53F7";
    const s = document.createElement("span");
    s.textContent = onlineCount > 0 ? `${onlineCount}/${n} \u5728\u7EBF` : `${n} \u4E2A\u8D26\u53F7`;
    inner.append(glyph, b, s);
    hub.append(inner);
    wheelEl.append(hub);
    requestAnimationFrame(() => requestAnimationFrame(() => wheelEl.classList.add("in")));
  }
  async function pick(accountId) {
    try {
      await chrome.runtime.sendMessage({ kind: "par.open", id: accountId });
    } finally {
      window.close();
    }
  }
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") {
      e.preventDefault();
      window.close();
      return;
    }
    const idx = Number(e.key) - 1;
    if (!Number.isNaN(idx) && idx >= 0 && idx < 9) {
      void fetchAccounts().then((accounts) => {
        if (idx < accounts.length) {
          void pick(accounts[idx].id);
        }
      });
    }
  });
  void fetchAccounts().then(render);
})();

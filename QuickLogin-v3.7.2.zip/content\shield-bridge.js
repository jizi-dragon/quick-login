"use strict";
(() => {
  // packages/extension/src/shared/constants.ts
  var CONTENT_MESSAGE = {
    setTitle: "sb:setTitle",
    autoLogin: "sb:autoLogin",
    autoLoginRequest: "sb:autoLoginRequest",
    /** ISOLATED 桥 → background（双向通路的上行） */
    bridgeUp: "ql:bridgeUp",
    /** background → ISOLATED 桥（下行） */
    bridgeDown: "ql:bridgeDown"
  };
  var WINDOW_CHANNEL = {
    pageToBridge: "QL_PAGE_TO_BRIDGE",
    bridgeToPage: "QL_BRIDGE_TO_PAGE"
  };

  // packages/extension/src/content/shield-bridge.ts
  function deliverDown(payload) {
    if (!payload) {
      return;
    }
    window.postMessage(
      { src: WINDOW_CHANNEL.bridgeToPage, payload },
      "*"
    );
  }
  async function routeUp(payload) {
    try {
      const res = await chrome.runtime.sendMessage({
        type: CONTENT_MESSAGE.bridgeUp,
        payload
      });
      deliverDown(res ?? null);
    } catch {
      deliverDown({ op: "unbound" });
    }
  }
  window.addEventListener("message", (event) => {
    if (event.source !== window) {
      return;
    }
    const data = event.data;
    if (!data || data.src !== WINDOW_CHANNEL.pageToBridge || !data.payload) {
      return;
    }
    void routeUp(data.payload);
  });
  chrome.runtime.onMessage.addListener((msg) => {
    const m = msg;
    if (m && m.type === CONTENT_MESSAGE.bridgeDown && m.payload) {
      deliverDown(m.payload);
    }
  });
})();

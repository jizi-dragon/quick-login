"use strict";
(() => {
  // packages/extension/src/shared/constants.ts
  var LOCAL_KEYS = {
    siteGrants: "sb:siteGrants",
    /** 手动停用的站点（Chrome 拒绝回收授权时本地封锁，不再对其安装改头规则） */
    blockedHosts: "ql:blockedHosts",
    /** 记忆的盒子清单（空盒子也保留；缺省「默认盒子」不入库） */
    boxList: "ql:boxes",
    /** 默认盒子的自定义名称（未归盒账号的归宿；缺省「默认盒子」） */
    defaultBox: "ql:defaultBox"
  };

  // packages/extension/src/ui/wheel/wheel-core.ts
  var WHEEL_MAX = 10;
  var NS = "http://www.w3.org/2000/svg";
  var SIZE = 520;
  var C = SIZE / 2;
  var R_OUT = 240;
  var R_IN = 118;
  var R_ARC = 254;
  var GAP_DEG = 2;
  var DEFAULT_BOX = "\u9ED8\u8BA4\u76D2\u5B50";
  function polar(r, deg) {
    const a = (deg - 90) * Math.PI / 180;
    return { x: C + r * Math.cos(a), y: C + r * Math.sin(a) };
  }
  function sectorPath(a0, a1) {
    const s = a0 + GAP_DEG / 2;
    const e = a1 - GAP_DEG / 2;
    const large = e - s > 180 ? 1 : 0;
    const p1 = polar(R_OUT, s);
    const p2 = polar(R_OUT, e);
    const p3 = polar(R_IN, e);
    const p4 = polar(R_IN, s);
    return [
      `M ${p1.x} ${p1.y}`,
      `A ${R_OUT} ${R_OUT} 0 ${large} 1 ${p2.x} ${p2.y}`,
      `L ${p3.x} ${p3.y}`,
      `A ${R_IN} ${R_IN} 0 ${large} 0 ${p4.x} ${p4.y}`,
      "Z"
    ].join(" ");
  }
  function el(name, attrs) {
    const node = document.createElementNS(NS, name);
    for (const [k, v] of Object.entries(attrs)) {
      node.setAttribute(k, String(v));
    }
    return node;
  }
  function radialText(cls, mid, r, content) {
    const p = polar(r, mid);
    const flip = mid > 90 && mid < 270;
    const rot = flip ? mid + 180 : mid;
    const t = el("text", {
      class: cls,
      x: p.x,
      y: p.y,
      "text-anchor": "middle",
      "dominant-baseline": "central",
      transform: `rotate(${rot} ${p.x} ${p.y})`
    });
    t.textContent = content;
    return t;
  }
  function truncate(s, max) {
    return s.length > max ? `${s.slice(0, max - 1)}\u2026` : s;
  }
  function groupPagesByBox(accounts, defaultBoxName = DEFAULT_BOX) {
    const pages = [];
    const byName = /* @__PURE__ */ new Map();
    for (const a of accounts) {
      const name = a.box?.trim() || defaultBoxName;
      if (!byName.has(name)) {
        byName.set(name, []);
        pages.push({ label: name, accounts: byName.get(name) });
      }
      byName.get(name).push(a);
    }
    return pages;
  }
  function buildSectorWheel(root, opts) {
    root.innerHTML = "";
    root.classList.add("sector-wheel");
    const pages = opts.pages;
    const page = pages[opts.pageIndex];
    const accounts = page?.accounts ?? [];
    const list = accounts.slice(0, WHEEL_MAX);
    const n = list.length;
    const onlineCount = accounts.filter((a) => (a.tabIds?.length ?? 0) > 0).length;
    const overflow = accounts.length > WHEEL_MAX;
    const pageCount = pages.length;
    const pagePos = pageCount > 0 ? opts.pageIndex % pageCount + 1 : 0;
    const svg = el("svg", { class: "sector-svg", viewBox: `0 0 ${SIZE} ${SIZE}` });
    const defs = el("defs", {});
    const grad = el("linearGradient", {
      id: "qlBoxGrad",
      gradientUnits: "userSpaceOnUse",
      x1: "387",
      y1: "40",
      x2: "387",
      y2: "480"
    });
    grad.append(
      el("stop", { offset: "0%", "stop-color": "#1E6FFF" }),
      el("stop", { offset: "55%", "stop-color": "#7C5CFF" }),
      el("stop", { offset: "100%", "stop-color": "#22C55E" })
    );
    defs.append(grad);
    svg.append(defs);
    const arcPt = (deg) => ({
      x: +(C + R_ARC * Math.cos(deg * Math.PI / 180)).toFixed(2),
      y: +(C + R_ARC * Math.sin(deg * Math.PI / 180)).toFixed(2)
    });
    const ARC_FROM = -60;
    const ARC_TO = 60;
    const pa = arcPt(ARC_FROM);
    const pb = arcPt(ARC_TO);
    svg.append(el("path", { class: "box-track", d: `M ${pa.x} ${pa.y} A ${R_ARC} ${R_ARC} 0 0 1 ${pb.x} ${pb.y}` }));
    const nodeAngle = (i) => pageCount > 1 ? ARC_FROM + (ARC_TO - ARC_FROM) * i / (pageCount - 1) : 0;
    for (let i = 0; i < pageCount; i++) {
      const pt = arcPt(nodeAngle(i));
      svg.append(el("circle", { class: "box-node", cx: pt.x, cy: pt.y, r: 5 }));
    }
    const curIdx = pageCount > 0 ? (opts.pageIndex % pageCount + pageCount) % pageCount : 0;
    const cur = arcPt(nodeAngle(curIdx));
    const active = el("circle", { class: "box-node-on", cx: cur.x, cy: cur.y, r: 7 });
    svg.append(active);
    const prevRaw = Number(root.dataset.qlWheelLastIdx ?? NaN);
    root.dataset.qlWheelLastIdx = String(curIdx);
    if (!Number.isNaN(prevRaw) && prevRaw !== curIdx && prevRaw >= 0 && prevRaw < pageCount) {
      const prev = arcPt(nodeAngle(prevRaw));
      const mid = arcPt((nodeAngle(prevRaw) + nodeAngle(curIdx)) / 2);
      active.animate(
        [
          { transform: `translate(${(prev.x - cur.x).toFixed(2)}px, ${(prev.y - cur.y).toFixed(2)}px)` },
          { transform: `translate(${(mid.x - cur.x).toFixed(2)}px, ${(mid.y - cur.y).toFixed(2)}px)`, offset: 0.5 },
          { transform: "translate(0px, 0px)" }
        ],
        { duration: 280, easing: "cubic-bezier(0.3, 0.9, 0.35, 1)" }
      );
    }
    if (n === 0) {
      svg.append(el("circle", { class: "hub-bg", cx: C, cy: C, r: R_IN - 6 }));
      const allEmpty = pages.every((p) => p.accounts.length === 0);
      const cap2 = el("text", { class: "hub-cap", x: C, y: C - 44, "text-anchor": "middle" });
      cap2.textContent = allEmpty ? "\u6682\u65E0\u5E76\u884C\u8D26\u53F7" : truncate(page?.label ?? DEFAULT_BOX, 10);
      const sub2 = el("text", { class: "hub-sub", x: C, y: C - 14, "text-anchor": "middle" });
      sub2.textContent = allEmpty ? "\u6DFB\u52A0\u8D26\u53F7\u540E\uFF0C\u8FD9\u91CC\u5373\u53EF\u5FEB\u901F\u5207\u6362\u8EAB\u4EFD" : "\u8BE5\u76D2\u5B50\u6682\u65E0\u8D26\u53F7 \xB7 \u6EDA\u8F6E\u6216\u70B9\u51FB Hub \u5207\u6362\u76D2\u5B50";
      svg.append(cap2, sub2);
      if (allEmpty && opts.emptyAction) {
        const goW = 150;
        const go = el("g", { class: "hub-go", tabindex: "0", role: "button" });
        go.append(el("rect", { class: "hub-go-rect", x: C - goW / 2, y: C + 10, width: goW, height: 38, rx: 19 }));
        const label = el("text", {
          class: "hub-go-text",
          x: C,
          y: C + 29,
          "text-anchor": "middle",
          "dominant-baseline": "central"
        });
        label.textContent = opts.emptyAction.label;
        go.append(label);
        go.addEventListener("click", () => opts.emptyAction.run());
        svg.append(go);
      }
      attachPageNav(root, opts);
      root.append(svg);
      return;
    }
    for (let i = 0; i < n; i++) {
      const account = list[i];
      const online = (account.tabIds?.length ?? 0) > 0;
      const a0 = 360 * i / n;
      const a1 = 360 * (i + 1) / n;
      const mid = (a0 + a1) / 2;
      const g = el("g", {
        class: `sector${online ? " is-online" : ""}`,
        style: `--acc:${account.color || "#1E6FFF"};--d:${(0.06 + i * 0.05).toFixed(2)}s`
      });
      g.append(el("path", { class: "sector-hit", d: sectorPath(a0, a1) }));
      const name = (account.tabName || account.username || "\u8D26\u53F7").trim();
      g.append(radialText("sector-label", mid, (R_IN + R_OUT) / 2 + 2, truncate(name, 8)));
      const numAt = polar(R_IN + 24, mid);
      const flip = mid > 90 && mid < 270;
      const numRot = flip ? mid + 180 : mid;
      const numG = el("g", { class: "sector-num", transform: `rotate(${numRot} ${numAt.x} ${numAt.y})` });
      numG.append(el("circle", { cx: numAt.x, cy: numAt.y, r: 11 }));
      const numText = el("text", { x: numAt.x, y: numAt.y, "text-anchor": "middle", "dominant-baseline": "central" });
      numText.textContent = String(i < 9 ? i + 1 : 0);
      numG.append(numText);
      g.append(numG);
      const dotAt = polar(R_OUT - 22, mid);
      g.append(el("circle", { class: `sector-dot${online ? " on" : ""}`, cx: dotAt.x, cy: dotAt.y, r: 5.5 }));
      g.addEventListener("click", () => opts.onPick(account.id));
      svg.append(g);
    }
    const hub = el("g", { class: "hub hub-click" });
    hub.append(el("circle", { class: "hub-bg", cx: C, cy: C, r: R_IN - 8 }));
    const cap = el("text", { class: "hub-box", x: C, y: C - 46, "text-anchor": "middle" });
    cap.textContent = truncate(page.label, 10);
    const num = el("text", { class: "hub-num", x: C, y: C + 6, "text-anchor": "middle", "dominant-baseline": "central" });
    num.append(document.createTextNode(String(onlineCount)));
    const den = el("tspan", { class: "den", dx: 3 });
    den.textContent = `/ ${n} \u5728\u7EBF`;
    num.append(den);
    const sub = el("text", { class: "hub-sub", x: C, y: C + 40, "text-anchor": "middle" });
    sub.textContent = overflow ? `\u76D2\u5B50\u5185 ${accounts.length} \u4E2A \xB7 \u4EC5\u663E\u793A\u524D ${WHEEL_MAX} \u4E2A` : `\u76D2\u5B50 ${pagePos}/${pageCount} \xB7 \u6EDA\u8F6E\u6216\u70B9\u51FB\u5207\u76D2`;
    hub.append(cap, num, sub);
    hub.addEventListener("click", () => opts.onPage(1));
    svg.append(hub);
    attachPageNav(root, opts);
    root.append(svg);
  }
  function attachPageNav(root, opts) {
    if (root.dataset.qlWheelNav === "1") {
      return;
    }
    root.dataset.qlWheelNav = "1";
    root.addEventListener(
      "wheel",
      (e) => {
        e.preventDefault();
        opts.onPage(e.deltaY > 0 ? 1 : -1);
      },
      { passive: false }
    );
  }

  // packages/extension/src/content/wheel-overlay.ts
  var WIN = window;
  var PARALLEL_PAGE = chrome.runtime.getURL("ui/parallel/parallel.html");
  if (WIN.__QL_WHEEL_ACTIVE__) {
    closeExisting();
  } else {
    void mount();
  }
  function closeExisting() {
    const prev = document.getElementById("ql-wheel-overlay-host");
    if (prev) {
      prev.dataset.forceClose = "1";
      prev.dispatchEvent(new CustomEvent("ql-wheel-close"));
      prev.remove();
    }
    document.documentElement.style.removeProperty("overflow");
    WIN.__QL_WHEEL_ACTIVE__ = false;
  }
  async function fetchAccounts() {
    const res = await chrome.runtime.sendMessage({ kind: "par.list" });
    return res?.result?.ok && Array.isArray(res.result.data) ? res.result.data : [];
  }
  async function fetchPages() {
    const [accounts, remembered, defaultBoxStore] = await Promise.all([
      fetchAccounts(),
      chrome.storage.local.get(LOCAL_KEYS.boxList).then((s) => s[LOCAL_KEYS.boxList] ?? []).catch(() => []),
      chrome.storage.local.get(LOCAL_KEYS.defaultBox).then((s) => s[LOCAL_KEYS.defaultBox]?.trim() ?? "").catch(() => "")
    ]);
    const pages = groupPagesByBox(accounts, defaultBoxStore || DEFAULT_BOX);
    const seen = new Set(pages.map((p) => p.label));
    for (const name of remembered) {
      if (!seen.has(name) && name !== defaultBoxStore) {
        pages.push({ label: name, accounts: [] });
      }
    }
    return pages;
  }
  async function mount() {
    const pages = await fetchPages();
    let pageIndex = 0;
    const host = document.createElement("div");
    host.id = "ql-wheel-overlay-host";
    const shadow = host.attachShadow({ mode: "open" });
    const style = document.createElement("style");
    style.textContent = `
    :host { all: initial; }
    * { margin:0; padding:0; box-sizing:border-box;
        font-family: system-ui,-apple-system,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif; }
    :host {
      position:fixed; inset:0; z-index:2147483646;
      display:flex; flex-direction:column; align-items:center; justify-content:center; gap:18px;
      background:rgba(241,245,252,.66);
      backdrop-filter:blur(10px) saturate(1.15);
      opacity:0; transition:opacity .18s ease;
    }
    :host(.show){opacity:1}

    .wheel-root{
      width:min(88vmin,560px);
      transform:scale(.9) translateY(10px);
      transition:transform .28s cubic-bezier(.22,1.3,.36,1), opacity .18s ease;
    }
    :host(.show) .wheel-root{transform:none}
    .wheel-root:not(.in){opacity:.35;transform:scale(.985) rotate(3deg)}

    .sector-wheel svg{
      width:100%; height:auto; display:block;
      filter: drop-shadow(0 26px 60px rgba(23,42,84,.16)) drop-shadow(0 2px 10px rgba(23,42,84,.08));
    }

    .box-track{fill:none;stroke:url(#qlBoxGrad);stroke-width:3.5;stroke-linecap:round}
    .box-node{fill:#b9c4d8;opacity:.55}
    .box-node-on{fill:#1e6fff;stroke:#fff;stroke-width:2;filter:drop-shadow(0 0 6px rgba(30,111,255,.55))}

    .sector{cursor:pointer;transform-box:view-box;transform-origin:50% 50%;
      transform:scale(.96);opacity:0;
      transition:transform .34s cubic-bezier(.22,1.2,.36,1),opacity .3s ease;
      transition-delay:var(--d,0s);}
    .sector-wheel.in .sector{opacity:1;transform:scale(1)}
    .sector:hover{transform:scale(1.016);transition-delay:0s}

    .sector-hit{fill:color-mix(in srgb,var(--acc,#1e6fff) 7%,#ffffff);
      stroke:color-mix(in srgb,var(--acc,#1e6fff) 26%,#e4eaf6);stroke-width:1.6;
      transition:fill .16s ease,stroke .16s ease}
    .sector:hover .sector-hit,.sector.hot .sector-hit{
      fill:color-mix(in srgb,var(--acc,#1e6fff) 20%,#ffffff);stroke:var(--acc,#1e6fff)}

    .sector-label{font-size:15px;font-weight:650;fill:#1b2a4a;letter-spacing:.02em;
      pointer-events:none;transition:fill .16s ease}
    .sector:hover .sector-label{fill:var(--acc,#1e6fff)}

    .sector-num circle{fill:#ffffff;stroke:color-mix(in srgb,var(--acc,#1e6fff) 30%,#e4eaf6);
      stroke-width:1.2;transition:stroke .16s ease,fill .16s ease}
    .sector:hover .sector-num circle{fill:var(--acc,#1e6fff);stroke:var(--acc,#1e6fff)}
    .sector-num text{font-size:11px;font-weight:700;fill:#66759b;
      font-variant-numeric:tabular-nums;pointer-events:none;transition:fill .16s ease}
    .sector:hover .sector-num text{fill:#ffffff}

    .sector-dot{fill:#cbd5e1;pointer-events:none;transition:fill .16s ease}
    .sector-dot.on{fill:#22c55e;filter:drop-shadow(0 0 4px rgba(34,197,94,.75));
      animation:ql-pulse 2.4s ease-in-out infinite;transform-box:fill-box;transform-origin:center}
    @keyframes ql-pulse{0%,100%{opacity:1}50%{opacity:.55}}

    .hub-click{cursor:pointer}
    .hub-bg{fill:#ffffff;stroke:#e4eaf6;stroke-width:1.5;transition:stroke .16s ease}
    .hub-click:hover .hub-bg{stroke:#1e6fff}
    .hub-box{font-size:15px;font-weight:700;fill:#1b2a4a;letter-spacing:.04em}
    .hub-num{font-size:46px;font-weight:800;fill:#1b2a4a;font-variant-numeric:tabular-nums}
    .hub-num .den{font-size:16px;font-weight:600;fill:#66759b;letter-spacing:.04em}
    .hub-sub{font-size:11px;fill:#66759b;letter-spacing:.05em;transition:fill .16s ease}
    .hub-click:hover .hub-sub{fill:#1e6fff}

    .hub-go{cursor:pointer}
    .hub-go-rect{fill:#1e6fff;transition:fill .15s ease}
    .hub-go:hover .hub-go-rect{fill:#185ed6}
    .hub-go-text{fill:#ffffff;font-size:13px;font-weight:600;pointer-events:none}

    .hint{
      display:flex; align-items:center; gap:9px;
      font-size:11.5px; color:#5b6b8f; letter-spacing:.05em;
      background:rgba(255,255,255,.82); border:1px solid rgba(228,234,246,.9);
      padding:6px 14px; border-radius:999px;
      box-shadow:0 2px 10px rgba(23,42,84,.06);
      opacity:0; transform:translateY(6px);
      transition:opacity .3s ease .25s, transform .3s ease .25s;
    }
    :host(.show) .hint{opacity:1;transform:none}
    .hint i{width:3px;height:3px;border-radius:50%;background:#c3cede}
    .hint kbd{display:inline-block;min-width:15px;padding:1.5px 6px;border-radius:5px;
      border:1px solid #d4ddf0;border-bottom-width:2px;background:#fff;color:#5b6b8f;
      font-family:inherit;font-size:10px;text-align:center}
  `;
    shadow.append(style);
    const wheelRoot = document.createElement("div");
    wheelRoot.className = "wheel-root";
    const hint = document.createElement("div");
    hint.className = "hint";
    hint.innerHTML = "<span><kbd>1-9</kbd> \u5FEB\u901F\u9009\u62E9</span><i></i><span>\u6EDA\u8F6E / \u70B9\u51FB\u4E2D\u5FC3\u5207\u76D2</span><i></i><span><kbd>Esc</kbd> \u5173\u95ED</span>";
    shadow.append(wheelRoot, hint);
    let closed = false;
    function close() {
      if (closed) {
        return;
      }
      closed = true;
      document.removeEventListener("keydown", onKeyDown, true);
      document.documentElement.style.removeProperty("overflow");
      host.classList.remove("show");
      WIN.__QL_WHEEL_ACTIVE__ = false;
      window.setTimeout(() => host.remove(), 220);
    }
    function onKeyDown(e) {
      const t = e.target;
      if (t && (t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.isContentEditable)) {
        return;
      }
      if (e.key === "Escape") {
        e.preventDefault();
        e.stopPropagation();
        close();
        return;
      }
      if (e.ctrlKey || e.altKey || e.metaKey) {
        return;
      }
      const page = pages[pageIndex];
      if (!page) {
        return;
      }
      const idx = Number(e.key) === 0 ? 9 : Number(e.key) - 1;
      if (!Number.isNaN(idx) && idx >= 0 && idx < 10 && idx < page.accounts.length) {
        void pick(page.accounts[idx].id);
      }
    }
    async function pick(accountId) {
      close();
      try {
        await chrome.runtime.sendMessage({ kind: "par.open", id: accountId });
      } catch {
      }
    }
    function render() {
      buildSectorWheel(wheelRoot, {
        pages,
        pageIndex,
        onPage: (delta) => {
          if (!pages.length) {
            return;
          }
          pageIndex = (pageIndex + delta + pages.length) % pages.length;
          render();
          requestAnimationFrame(() => requestAnimationFrame(() => wheelRoot.classList.add("in")));
        },
        onPick: (id) => void pick(id),
        emptyAction: {
          label: "\u53BB\u5E76\u884C\u7BA1\u7406\u9875\u6DFB\u52A0",
          run: () => {
            close();
            void chrome.tabs.create({ url: PARALLEL_PAGE });
          }
        }
      });
      requestAnimationFrame(() => requestAnimationFrame(() => wheelRoot.classList.add("in")));
    }
    document.addEventListener("keydown", onKeyDown, true);
    document.documentElement.style.setProperty("overflow", "hidden");
    document.documentElement.append(host);
    WIN.__QL_WHEEL_ACTIVE__ = true;
    render();
    requestAnimationFrame(
      () => requestAnimationFrame(() => {
        host.classList.add("show");
      })
    );
  }
})();

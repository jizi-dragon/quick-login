"use strict";
(() => {
  // packages/extension/src/shared/constants.ts
  var EXT_VERSION = "3.9.6";
  var LOCAL_KEYS = {
    siteGrants: "sb:siteGrants",
    /** 手动停用的站点（Chrome 拒绝回收授权时本地封锁，不再对其安装改头规则） */
    blockedHosts: "ql:blockedHosts",
    /** 记忆的盒子清单（空盒子也保留；缺省「默认盒子」不入库） */
    boxList: "ql:boxes",
    /** 默认盒子的自定义名称（未归盒账号的归宿；缺省「默认盒子」） */
    defaultBox: "ql:defaultBox"
  };

  // packages/extension/src/ui/send.ts
  function send(req) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage(req, resolve);
    });
  }

  // packages/extension/src/ui/parallel/parallel.ts
  var verChip = document.getElementById("ver-chip");
  verChip.textContent = `v${EXT_VERSION}`;
  var browserListEl = document.getElementById("browser-list");
  var parForm = document.getElementById("par-form");
  var pHostSelect = document.getElementById("p-host");
  var pBoxSelect = document.getElementById("p-box");
  var pTabName = document.getElementById("p-tabname");
  var pUsername = document.getElementById("p-username");
  var pPassword = document.getElementById("p-password");
  var boxChipsEl = document.getElementById("box-chips");
  var batchToggle = document.getElementById("batch-toggle");
  var batchBar = document.getElementById("batch-bar");
  var selCount = document.getElementById("sel-count");
  var selClear = document.getElementById("sel-clear");
  var selMove = document.getElementById("sel-move");
  var selDelete = document.getElementById("sel-delete");
  var siteForm = document.getElementById("site-form");
  var sHost = document.getElementById("s-host");
  var siteListEl = document.getElementById("site-list");
  var importToggle = document.getElementById("import-toggle");
  var importPanel = document.getElementById("import-panel");
  var importText = document.getElementById("import-text");
  var importRun = document.getElementById("import-run");
  var importCancel = document.getElementById("import-cancel");
  var boxModal = document.getElementById("box-modal");
  var boxModalList = document.getElementById("box-modal-list");
  var boxModalNew = document.getElementById("box-modal-new");
  var boxModalOk = document.getElementById("box-modal-ok");
  var boxModalCancel = document.getElementById("box-modal-cancel");
  var PREFERRED_HOST = "tonbridge-config.aksoegmp.com";
  var LAST_HOST_KEY = "ql:lastParHost";
  var LAST_BOX_KEY = "ql:lastParBox";
  var DEFAULT_BOX_FALLBACK = "\u9ED8\u8BA4\u76D2\u5B50";
  var defaultBox = DEFAULT_BOX_FALLBACK;
  var browserAccounts = [];
  var grantedHosts = [];
  var blockedHosts = [];
  var boxes = [DEFAULT_BOX_FALLBACK];
  var currentBox = "\u5168\u90E8";
  var batchMode = false;
  var selectedIds = /* @__PURE__ */ new Set();
  var lastListKey = "";
  var lastSitesKey = "";
  var lastChipsKey = "";
  var lastHostOptions = "";
  var lastBoxOptions = "";
  function setStat(id, value) {
    const el = document.getElementById(id);
    if (el) {
      el.textContent = String(value);
    }
  }
  function boxOf(a) {
    return a.box?.trim() || defaultBox;
  }
  async function loadBrowserAccounts() {
    const res = await send({ kind: "par.list" });
    browserAccounts = res.kind === "par.list" && res.result.ok ? res.result.data : [];
    for (const id of Array.from(selectedIds)) {
      if (!browserAccounts.some((a) => a.id === id)) {
        selectedIds.delete(id);
      }
    }
    const key = JSON.stringify([defaultBox, browserAccounts.map((a) => [
      a.id,
      a.tabName,
      a.username,
      a.siteHost,
      a.color,
      a.password,
      a.tabIds,
      a.hasToken,
      a.enforcementOff ?? false,
      a.box ?? ""
    ])]);
    if (key !== lastListKey) {
      lastListKey = key;
      renderBrowserAccounts();
    } else if (batchMode) {
      syncBatchBar();
    }
    setStat("stat-accounts", browserAccounts.length);
    setStat("stat-online", browserAccounts.filter((a) => a.tabIds.length > 0).length);
  }
  function badgeOf(a) {
    if (a.enforcementOff) {
      return { cls: "login_failed", text: "\u672A\u6388\u6743 \xB7 \u5DF2\u6682\u505C" };
    }
    if (a.hasToken && a.tabIds.length > 0) {
      return { cls: "online", text: `\u5728\u7EBF \xD7${a.tabIds.length}` };
    }
    if (a.tabIds.length > 0) {
      return { cls: "starting", text: "\u5F85\u767B\u5F55" };
    }
    return { cls: "offline", text: "\u79BB\u7EBF" };
  }
  function renderBrowserAccounts() {
    browserListEl.innerHTML = "";
    browserListEl.classList.toggle("batch-on", batchMode);
    const filtered = currentBox === "\u5168\u90E8" ? browserAccounts : browserAccounts.filter((a) => boxOf(a) === currentBox);
    if (!filtered.length) {
      const li = document.createElement("li");
      li.className = "empty";
      const ico = document.createElement("div");
      ico.className = "empty-ico";
      ico.textContent = "\u{1F5C2}\uFE0F";
      const tip = document.createElement("div");
      tip.textContent = browserAccounts.length ? `\u76D2\u5B50\u300C${currentBox}\u300D\u6682\u65E0\u8D26\u53F7\u3002\u628A\u5176\u5B83\u76D2\u5B50\u7684\u8D26\u53F7\u79FB\u5165\uFF0C\u6216\u5728\u53F3\u4FA7\u8868\u5355\u76F4\u63A5\u6DFB\u52A0\u5230\u8BE5\u76D2\u5B50\u3002` : "\u8FD8\u6CA1\u6709\u5E76\u884C\u8D26\u53F7\u3002\u5728\u4E0B\u65B9\u8868\u5355\u586B\u5199\u5E76\u300C\u6DFB\u52A0\u5E76\u6253\u5F00\u300D\uFF0C\u5BC6\u7801\u5C06\u4EE5 AES-GCM \u52A0\u5BC6\u5B58\u653E\u5728\u672C\u673A\u3002";
      li.append(ico, tip);
      browserListEl.appendChild(li);
      return;
    }
    for (const a of filtered) {
      const li = document.createElement("li");
      li.className = "account-card" + (selectedIds.has(a.id) ? " selected" : "");
      li.style.setProperty("--accent", a.color);
      li.dataset.id = a.id;
      if (batchMode) {
        const check = document.createElement("input");
        check.type = "checkbox";
        check.className = "ac-check";
        check.checked = selectedIds.has(a.id);
        check.title = "\u9009\u62E9\u8BE5\u8D26\u53F7";
        check.addEventListener("change", () => {
          if (check.checked) {
            selectedIds.add(a.id);
          } else {
            selectedIds.delete(a.id);
          }
          li.classList.toggle("selected", check.checked);
          syncBatchBar();
        });
        li.append(check);
      }
      const head = document.createElement("div");
      head.className = "ac-head";
      const avatar = document.createElement("span");
      avatar.className = "ac-avatar";
      avatar.style.setProperty("--ring", a.color);
      avatar.textContent = (a.tabName || a.username).trim().charAt(0).toUpperCase() || "?";
      const online = a.tabIds.length > 0;
      const dot = document.createElement("i");
      dot.className = online ? "dot on" : "dot";
      avatar.append(dot);
      const meta = document.createElement("div");
      meta.className = "meta";
      const alias = document.createElement("div");
      alias.className = "alias";
      alias.textContent = a.tabName || a.username;
      const sub = document.createElement("div");
      sub.className = "sub";
      const boxTag = document.createElement("span");
      boxTag.className = "box-tag";
      boxTag.textContent = boxOf(a);
      sub.append(boxTag, `${a.username} \xB7 ${a.siteHost}${a.password ? " \xB7 \u5DF2\u5B58\u5BC6\u7801" : ""}`);
      meta.append(alias, sub);
      const badge = document.createElement("span");
      const b = badgeOf(a);
      badge.className = `badge ${b.cls}`;
      badge.textContent = b.text;
      head.append(avatar, meta, badge);
      const actions = document.createElement("div");
      actions.className = "ac-actions";
      const openBtn = document.createElement("button");
      openBtn.className = "btn-ghost";
      openBtn.textContent = a.tabIds.length ? "\u805A\u7126\u6807\u7B7E\u9875" : "\u6253\u5F00";
      openBtn.addEventListener("click", () => void openAccount(a.id, false));
      const newTabBtn = document.createElement("button");
      newTabBtn.className = "btn-ghost";
      newTabBtn.textContent = "\u65B0\u6807\u7B7E\u9875";
      newTabBtn.addEventListener("click", () => void openAccount(a.id, true));
      const renameBtn = document.createElement("button");
      renameBtn.className = "btn-ghost";
      renameBtn.textContent = "\u6539\u9875\u7B7E\u540D";
      renameBtn.addEventListener("click", () => {
        const next = prompt("\u65B0\u7684\u9875\u7B7E\u540D\uFF08\u8BE5\u8D26\u53F7\u6807\u7B7E\u9875\u7684\u6807\u9898\uFF09", a.tabName || a.username);
        if (next === null) {
          return;
        }
        void (async () => {
          await send({ kind: "par.update", id: a.id, patch: { tabName: next.trim() || a.username } });
          await refreshAll();
        })();
      });
      const moveBtn = document.createElement("button");
      moveBtn.className = "btn-ghost";
      moveBtn.textContent = "\u79FB\u5165\u76D2\u5B50";
      moveBtn.addEventListener("click", () => openBoxChooser([a.id]));
      const del = document.createElement("button");
      del.className = "btn-danger";
      del.textContent = "\u5220\u9664";
      del.addEventListener("click", () => {
        if (confirm(`\u5220\u9664\u8D26\u53F7\u300C${a.tabName || a.username}\u300D\uFF1F\u5C06\u540C\u65F6\u5173\u95ED\u5176\u6240\u6709\u5E76\u884C\u6807\u7B7E\u9875\u3002`)) {
          void (async () => {
            await send({ kind: "par.delete", id: a.id });
            await refreshAll();
          })();
        }
      });
      actions.append(openBtn, newTabBtn, renameBtn, moveBtn, del);
      li.append(head, actions);
      browserListEl.appendChild(li);
    }
  }
  async function loadBoxes() {
    const stored = await chrome.storage.local.get([LOCAL_KEYS.boxList, LOCAL_KEYS.defaultBox]);
    const remembered = stored[LOCAL_KEYS.boxList] ?? [];
    defaultBox = (stored[LOCAL_KEYS.defaultBox] ?? "").trim() || DEFAULT_BOX_FALLBACK;
    const fromAccounts = browserAccounts.map((a) => boxOf(a));
    boxes = [.../* @__PURE__ */ new Set([defaultBox, ...remembered.filter((b) => b !== defaultBox), ...fromAccounts])];
    setStat("stat-boxes", boxes.length);
  }
  async function saveBoxes() {
    await chrome.storage.local.set({ [LOCAL_KEYS.boxList]: boxes.filter((b) => b !== defaultBox) });
  }
  function renderBoxChips() {
    const key = JSON.stringify([boxes, currentBox, browserAccounts.map((a) => boxOf(a)), batchMode]);
    if (key === lastChipsKey) {
      return;
    }
    lastChipsKey = key;
    boxChipsEl.innerHTML = "";
    const countOf = (name) => browserAccounts.filter((a) => boxOf(a) === name).length;
    const all = document.createElement("button");
    all.type = "button";
    all.className = "chip" + (currentBox === "\u5168\u90E8" ? " active" : "");
    const allLabel = document.createElement("span");
    allLabel.textContent = "\u5168\u90E8";
    const allN = document.createElement("span");
    allN.className = "chip-n";
    allN.textContent = String(browserAccounts.length);
    all.append(allLabel, allN);
    all.addEventListener("click", () => {
      currentBox = "\u5168\u90E8";
      lastListKey = "";
      renderBoxChips();
      renderBrowserAccounts();
    });
    boxChipsEl.append(all);
    for (const name of boxes) {
      const chip = document.createElement("button");
      chip.type = "button";
      chip.className = "chip" + (currentBox === name ? " active" : "");
      const label = document.createElement("span");
      label.textContent = name;
      const n = document.createElement("span");
      n.className = "chip-n";
      n.textContent = String(countOf(name));
      chip.append(label, n);
      const rename = document.createElement("span");
      rename.className = "chip-act";
      rename.textContent = "\u270E";
      rename.addEventListener("click", (e) => {
        e.stopPropagation();
        void renameBoxFlow(name);
      });
      if (name === defaultBox) {
        rename.title = "\u4FEE\u6539\u9ED8\u8BA4\u76D2\u5B50\u540D\u79F0\uFF08\u672A\u5F52\u76D2\u8D26\u53F7\u7684\u5F52\u5BBF\uFF09";
        chip.append(rename);
        chip.title = "\u9ED8\u8BA4\u76D2\u5B50\uFF1A\u672A\u5F52\u76D2\u8D26\u53F7\u7684\u5F52\u5BBF\uFF0C\u53EF\u91CD\u547D\u540D\uFF0C\u4E0D\u53EF\u5220\u9664";
      } else {
        rename.title = "\u91CD\u547D\u540D\u76D2\u5B50\uFF08\u76D2\u5185\u8D26\u53F7\u968F\u8FC1\uFF09";
        const remove = document.createElement("span");
        remove.className = "chip-act chip-act-del";
        remove.textContent = "\u2715";
        remove.title = "\u5220\u9664\u76D2\u5B50\uFF08\u76D2\u5185\u8D26\u53F7\u56DE\u5230\u9ED8\u8BA4\u76D2\u5B50\uFF09";
        remove.addEventListener("click", (e) => {
          e.stopPropagation();
          void removeBoxFlow(name);
        });
        chip.append(rename, remove);
      }
      chip.addEventListener("click", () => {
        currentBox = name;
        lastListKey = "";
        renderBoxChips();
        renderBrowserAccounts();
      });
      boxChipsEl.append(chip);
    }
    const add = document.createElement("button");
    add.type = "button";
    add.className = "chip chip-add";
    add.textContent = "\uFF0B \u65B0\u5EFA\u76D2\u5B50";
    add.addEventListener("click", () => void createBox());
    boxChipsEl.append(add);
  }
  async function createBox() {
    const name = prompt("\u65B0\u76D2\u5B50\u540D\u79F0\uFF08\u8D26\u53F7\u6309\u76D2\u5B50\u6536\u7EB3\uFF0C\u8F6E\u76D8\u6309\u76D2\u5B50\u7FFB\u9875\uFF09", "");
    const trimmed = name?.trim();
    if (!trimmed) {
      return;
    }
    if (boxes.includes(trimmed)) {
      alert(`\u76D2\u5B50\u300C${trimmed}\u300D\u5DF2\u5B58\u5728\u3002`);
      return;
    }
    boxes.push(trimmed);
    await saveBoxes();
    lastChipsKey = "";
    lastBoxOptions = "";
    renderBoxChips();
    fillBoxOptions();
  }
  async function renameBoxFlow(from) {
    const isDefault = from === defaultBox;
    const input = prompt(
      isDefault ? `\u4FEE\u6539\u9ED8\u8BA4\u76D2\u5B50\u540D\u79F0\uFF08\u5F53\u524D\u300C${from}\u300D\uFF09\u3002\u672A\u5F52\u76D2\u8D26\u53F7\u5C06\u663E\u793A\u5728\u65B0\u540D\u79F0\u4E0B\u3002` : `\u91CD\u547D\u540D\u76D2\u5B50\u300C${from}\u300D\uFF08\u76D2\u5185\u8D26\u53F7\u968F\u8FC1\uFF09`,
      from
    );
    const to = input?.trim();
    if (!to || to === from) {
      return;
    }
    if (isDefault) {
      if (boxes.includes(to)) {
        alert(`\u76D2\u5B50\u300C${to}\u300D\u5DF2\u5B58\u5728\uFF0C\u9ED8\u8BA4\u76D2\u5B50\u4E0D\u80FD\u4E0E\u5176\u5B83\u76D2\u5B50\u91CD\u540D\u3002`);
        return;
      }
      defaultBox = to;
      await chrome.storage.local.set({ [LOCAL_KEYS.defaultBox]: to });
      boxes = boxes.map((b) => b === from ? to : b);
      if (currentBox === from) {
        currentBox = to;
      }
      lastChipsKey = "";
      lastBoxOptions = "";
      lastListKey = "";
      await refreshAll();
      return;
    }
    if (boxes.includes(to) && !confirm(`\u76D2\u5B50\u300C${to}\u300D\u5DF2\u5B58\u5728\uFF0C\u5C06\u628A\u300C${from}\u300D\u4E2D\u7684\u8D26\u53F7\u5E76\u5165\u5176\u4E2D\u3002\u7EE7\u7EED\uFF1F`)) {
      return;
    }
    const res = await send({ kind: "par.renameBox", from, to });
    if (!(res.kind === "par.renameBox" && res.result.ok)) {
      alert(`\u91CD\u547D\u540D\u5931\u8D25\uFF1A${res.kind === "par.renameBox" && !res.result.ok ? res.result.error : "\u65E0\u54CD\u5E94"}`);
      return;
    }
    boxes = [...new Set(boxes.map((b) => b === from ? to : b))];
    await saveBoxes();
    if (currentBox === from) {
      currentBox = to;
    }
    lastChipsKey = "";
    lastBoxOptions = "";
    lastListKey = "";
    await refreshAll();
  }
  async function removeBoxFlow(name) {
    if (name === defaultBox) {
      return;
    }
    const count = browserAccounts.filter((a) => boxOf(a) === name).length;
    const tip = count ? `\u5220\u9664\u76D2\u5B50\u300C${name}\u300D\uFF1F\u5176\u4E2D ${count} \u4E2A\u8D26\u53F7\u5C06\u56DE\u5230\u300C${defaultBox}\u300D\u3002` : `\u5220\u9664\u7A7A\u76D2\u5B50\u300C${name}\u300D\uFF1F`;
    if (!confirm(tip)) {
      return;
    }
    const res = await send({ kind: "par.deleteBox", name });
    if (!(res.kind === "par.deleteBox" && res.result.ok)) {
      alert(`\u5220\u9664\u5931\u8D25\uFF1A${res.kind === "par.deleteBox" && !res.result.ok ? res.result.error : "\u65E0\u54CD\u5E94"}`);
      return;
    }
    boxes = boxes.filter((b) => b !== name);
    await saveBoxes();
    if (currentBox === name) {
      currentBox = "\u5168\u90E8";
    }
    lastChipsKey = "";
    lastBoxOptions = "";
    lastListKey = "";
    await refreshAll();
  }
  function syncBatchBar() {
    selCount.textContent = String(selectedIds.size);
    batchBar.classList.toggle("hidden", !batchMode);
  }
  batchToggle.addEventListener("click", () => {
    batchMode = !batchMode;
    batchToggle.textContent = batchMode ? "\u9000\u51FA\u6279\u91CF" : "\u6279\u91CF\u7BA1\u7406";
    if (!batchMode) {
      selectedIds.clear();
    }
    lastListKey = "";
    renderBrowserAccounts();
    syncBatchBar();
    lastChipsKey = "";
    renderBoxChips();
  });
  selClear.addEventListener("click", () => {
    selectedIds.clear();
    lastListKey = "";
    renderBrowserAccounts();
    syncBatchBar();
  });
  selMove.addEventListener("click", () => {
    if (!selectedIds.size) {
      return;
    }
    openBoxChooser([...selectedIds]);
  });
  selDelete.addEventListener("click", () => {
    if (!selectedIds.size) {
      return;
    }
    if (!confirm(`\u5220\u9664\u9009\u4E2D\u7684 ${selectedIds.size} \u4E2A\u8D26\u53F7\uFF1F\u5C06\u540C\u65F6\u5173\u95ED\u5B83\u4EEC\u7684\u6240\u6709\u5E76\u884C\u6807\u7B7E\u9875\u3002`)) {
      return;
    }
    void (async () => {
      for (const id of selectedIds) {
        await send({ kind: "par.delete", id });
      }
      selectedIds.clear();
      await refreshAll();
    })();
  });
  var pendingMoveIds = [];
  var modalPick = DEFAULT_BOX_FALLBACK;
  function openBoxChooser(ids) {
    if (!ids.length) {
      return;
    }
    pendingMoveIds = ids;
    const first = browserAccounts.find((a) => a.id === ids[0]);
    modalPick = currentBox !== "\u5168\u90E8" ? currentBox : first ? boxOf(first) : DEFAULT_BOX_FALLBACK;
    boxModalNew.value = "";
    renderBoxModalList();
    boxModal.classList.remove("hidden");
  }
  function renderBoxModalList() {
    boxModalList.innerHTML = "";
    const typing = boxModalNew.value.trim();
    for (const name of boxes) {
      const row = document.createElement("button");
      row.type = "button";
      row.className = "box-option" + (!typing && modalPick === name ? " active" : "");
      const label = document.createElement("span");
      label.textContent = name;
      const count = document.createElement("span");
      count.className = "chip-n";
      count.textContent = String(browserAccounts.filter((a) => boxOf(a) === name).length);
      row.append(label, count);
      row.addEventListener("click", () => {
        modalPick = name;
        boxModalNew.value = "";
        renderBoxModalList();
      });
      boxModalList.append(row);
    }
  }
  boxModalNew.addEventListener("input", () => {
    const typed = boxModalNew.value.trim();
    if (typed) {
      modalPick = typed;
      renderBoxModalList();
    } else {
      const first = browserAccounts.find((a) => a.id === pendingMoveIds[0]);
      modalPick = currentBox !== "\u5168\u90E8" ? currentBox : first ? boxOf(first) : DEFAULT_BOX_FALLBACK;
      renderBoxModalList();
    }
  });
  function hideBoxModal() {
    boxModal.classList.add("hidden");
    pendingMoveIds = [];
  }
  boxModalOk.addEventListener("click", () => {
    void (async () => {
      const target = (boxModalNew.value.trim() || modalPick).trim() || defaultBox;
      const ids = [...pendingMoveIds];
      hideBoxModal();
      if (!ids.length) {
        return;
      }
      for (const id of ids) {
        await send({ kind: "par.moveBox", id, box: target === defaultBox ? "" : target });
      }
      if (target !== defaultBox && !boxes.includes(target)) {
        boxes.push(target);
        await saveBoxes();
        lastBoxOptions = "";
      }
      if (currentBox !== "\u5168\u90E8" && currentBox !== target) {
        currentBox = target;
      }
      selectedIds.clear();
      lastChipsKey = "";
      lastListKey = "";
      await refreshAll();
    })();
  });
  boxModalCancel.addEventListener("click", hideBoxModal);
  boxModal.addEventListener("click", (e) => {
    if (e.target === boxModal) {
      hideBoxModal();
    }
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && !boxModal.classList.contains("hidden")) {
      hideBoxModal();
    }
  });
  importToggle.addEventListener("click", () => {
    importPanel.classList.toggle("hidden");
  });
  importCancel.addEventListener("click", () => {
    importPanel.classList.add("hidden");
  });
  function parseImportText(text) {
    const trimmed = text.trim();
    if (!trimmed) {
      return [];
    }
    try {
      const parsed = JSON.parse(trimmed);
      if (Array.isArray(parsed)) {
        return parsed.map((row) => {
          const r = row;
          return {
            tabName: String(r.tabName ?? r["\u9875\u7B7E\u540D"] ?? "").trim(),
            username: String(r.username ?? r["\u8D26\u53F7\u540D"] ?? "").trim(),
            password: String(r.password ?? r["\u5BC6\u7801"] ?? "").trim()
          };
        }).filter((r) => r.username && r.password);
      }
    } catch {
    }
    return trimmed.split(/\r?\n/).map((line) => line.trim()).filter(Boolean).map((line) => {
      const parts = line.split(/[,，\t]/).map((s) => s.trim());
      return { tabName: parts[0] ?? "", username: parts[1] ?? "", password: parts[2] ?? "" };
    }).filter((r) => r.username && r.password);
  }
  importRun.addEventListener("click", () => {
    void (async () => {
      const siteHost = pHostSelect.value;
      if (!siteHost) {
        alert("\u8BF7\u5148\u5728\u300C\u7AD9\u70B9\u7BA1\u7406\u300D\u6DFB\u52A0\u5E76\u6388\u6743\u7AD9\u70B9\u3002");
        return;
      }
      const box = pBoxSelect.value;
      const rows = parseImportText(importText.value);
      if (!rows.length) {
        alert("\u6CA1\u6709\u53EF\u5BFC\u5165\u7684\u884C\u3002\u8BF7\u68C0\u67E5\u683C\u5F0F\uFF1A\u6BCF\u884C\u300C\u9875\u7B7E\u540D,\u8D26\u53F7\u540D,\u5BC6\u7801\u300D\uFF0C\u6216 JSON \u6570\u7EC4\u3002");
        return;
      }
      let okCount = 0;
      let failCount = 0;
      for (const row of rows) {
        try {
          const res = await send({
            kind: "par.create",
            siteHost,
            tabName: row.tabName,
            username: row.username,
            password: row.password,
            open: false,
            box
          });
          if (res.result.ok) {
            okCount += 1;
          } else {
            failCount += 1;
          }
        } catch {
          failCount += 1;
        }
      }
      if (okCount) {
        await chrome.storage.local.set({ [LAST_HOST_KEY]: siteHost });
      }
      importText.value = "";
      importPanel.classList.add("hidden");
      await refreshAll();
      alert(`\u6279\u91CF\u5BFC\u5165\u5B8C\u6210\uFF1A\u6210\u529F ${okCount} \u4E2A${failCount ? `\uFF0C\u5931\u8D25 ${failCount} \u6761\uFF08\u7F3A\u8D26\u53F7\u540D\u6216\u5BC6\u7801\uFF09` : ""}\u3002\u8D26\u53F7\u5DF2\u4FDD\u5B58\u5230\u76D2\u5B50\u300C${box}\u300D\uFF0C\u53EF\u4ECE\u5217\u8868\u9010\u4E2A\u6253\u5F00\u3002`);
    })();
  });
  async function ensureHostPermission(host) {
    try {
      return await chrome.permissions.request({ origins: [`*://${host}/*`] });
    } catch {
      return false;
    }
  }
  async function openAccount(id, forceNewTab) {
    const account = browserAccounts.find((x) => x.id === id);
    if (!account) {
      return;
    }
    if (!await ensureHostPermission(account.siteHost)) {
      alert(`\u9700\u8981\u6388\u6743\u8BBF\u95EE ${account.siteHost} \u624D\u80FD\u6539\u5199\u5176\u8BF7\u6C42\u5934\u3002`);
      return;
    }
    const res = await send({ kind: "par.open", id, forceNewTab });
    if (!res.result.ok) {
      alert(`\u6253\u5F00\u5931\u8D25\uFF1A${res.result.error}`);
      return;
    }
    await refreshAll();
  }
  async function createAccount(open) {
    const siteHost = pHostSelect.value;
    if (!siteHost) {
      alert("\u8BF7\u5148\u5728\u300C\u7AD9\u70B9\u7BA1\u7406\u300D\u6DFB\u52A0\u5E76\u6388\u6743\u7AD9\u70B9\uFF0C\u7AD9\u70B9\u4E0B\u62C9\u624D\u4F1A\u6709\u53EF\u9009\u9879\u3002");
      return;
    }
    const tabName = pTabName.value.trim();
    const username = pUsername.value.trim();
    const password = pPassword.value;
    if (!username || !password) {
      return;
    }
    const res = await send({
      kind: "par.create",
      siteHost,
      tabName,
      username,
      password,
      open,
      box: pBoxSelect.value
    });
    if (!res.result.ok) {
      alert(`\u6DFB\u52A0\u5931\u8D25\uFF1A${res.result.error}`);
      return;
    }
    await chrome.storage.local.set({ [LAST_HOST_KEY]: siteHost, [LAST_BOX_KEY]: pBoxSelect.value });
    pTabName.value = "";
    pUsername.value = "";
    pPassword.value = "";
    await refreshAll();
  }
  parForm.addEventListener("submit", (e) => {
    e.preventDefault();
    void createAccount(true);
  });
  document.getElementById("add-only").addEventListener("click", () => {
    void createAccount(false);
  });
  function originToHost(origin) {
    const m = /^(?:\*|https?):\/\/([^/]+)(?:\/.*)?$/.exec(origin);
    if (!m) {
      return null;
    }
    return m[1] === "*" ? null : m[1];
  }
  function patternOfHost(host) {
    return `*://${host}/*`;
  }
  function countAccountsFor(displayHost) {
    const bare = displayHost.replace(/^\*\./, "");
    return browserAccounts.filter((a) => a.siteHost === displayHost || a.siteHost.endsWith(`.${bare}`)).length;
  }
  async function loadSites() {
    const all = await chrome.permissions.getAll();
    const blockedStored = await chrome.storage.local.get(LOCAL_KEYS.blockedHosts);
    const blocked = new Set(blockedStored[LOCAL_KEYS.blockedHosts] ?? []);
    grantedHosts = Array.from(
      new Set((all.origins ?? []).map(originToHost).filter((h) => h !== null))
    ).sort();
    for (const b of Array.from(blocked)) {
      const still = await chrome.permissions.contains({ origins: [`*://${b}/*`] }).catch(() => false);
      if (!still) {
        blocked.delete(b);
      }
    }
    blockedHosts = Array.from(blocked).sort();
    await chrome.storage.local.set({ [LOCAL_KEYS.blockedHosts]: blockedHosts });
    const sitesKey = JSON.stringify([
      grantedHosts,
      blockedHosts,
      browserAccounts.map((a) => [a.id, a.tabName, a.box ?? ""])
    ]);
    if (sitesKey !== lastSitesKey) {
      lastSitesKey = sitesKey;
      renderSites(grantedHosts, blockedHosts);
    }
  }
  function renderSites(hosts, blocked = []) {
    siteListEl.innerHTML = "";
    if (!hosts.length && !blocked.length) {
      const li = document.createElement("li");
      li.className = "empty";
      const ico = document.createElement("div");
      ico.className = "empty-ico";
      ico.textContent = "\u{1F6E1}\uFE0F";
      const tip = document.createElement("div");
      tip.textContent = "\u5C1A\u65E0\u6388\u6743\u7AD9\u70B9\u3002\u7528\u4E0A\u65B9\u8868\u5355\u8F93\u5165 host \u6DFB\u52A0\u5E76\u6388\u6743\u3002";
      li.append(ico, tip);
      siteListEl.appendChild(li);
      return;
    }
    const seen = /* @__PURE__ */ new Set();
    for (const host of [...hosts, ...blocked]) {
      if (seen.has(host)) {
        continue;
      }
      seen.add(host);
      const isBlocked = !hosts.includes(host) || blocked.includes(host);
      const n = countAccountsFor(host);
      const li = document.createElement("li");
      li.className = "site-row";
      const meta = document.createElement("div");
      meta.className = "meta";
      const alias = document.createElement("div");
      alias.className = "alias";
      alias.textContent = isBlocked ? `${host}\uFF08\u5DF2\u505C\u7528\uFF09` : host;
      if (isBlocked) {
        alias.style.color = "#C2410C";
      }
      const sub = document.createElement("div");
      sub.className = "sub";
      sub.textContent = isBlocked ? `${n} \u4E2A\u5E76\u884C\u8D26\u53F7 \xB7 \u6539\u5934\u89C4\u5219\u5DF2\u5168\u90E8\u6682\u505C` : n > 0 ? `${n} \u4E2A\u5E76\u884C\u8D26\u53F7` : "\u8BE5\u7AD9\u70B9\u6682\u65E0\u5E76\u884C\u8D26\u53F7\uFF08\u6DFB\u52A0\u8D26\u53F7\u540E\u81EA\u52A8\u66F4\u65B0\uFF09";
      meta.append(alias, sub);
      const actionBtn = document.createElement("button");
      actionBtn.className = isBlocked ? "btn-ghost" : "btn-danger";
      actionBtn.textContent = isBlocked ? "\u6062\u590D\u4F7F\u7528" : "\u79FB\u9664\u6388\u6743";
      actionBtn.addEventListener("click", () => {
        if (isBlocked) {
          void unblockHost(host);
          return;
        }
        if (!confirm(`\u79FB\u9664\u5BF9 ${host} \u7684\u6388\u6743\uFF1F\u8BE5\u7AD9\u70B9\u7684\u9274\u6743\u6539\u5199\u5C06\u7ACB\u5373\u5931\u6548\uFF08\u6D4F\u89C8\u5668\u5185\u7684\u767B\u5F55\u6001\u4E0D\u53D7\u5F71\u54CD\uFF09\u3002`)) {
          return;
        }
        void revokeHost(host);
      });
      li.append(meta, actionBtn);
      siteListEl.appendChild(li);
    }
  }
  async function revokeHost(displayHost) {
    const all = await chrome.permissions.getAll();
    const raws = (all.origins ?? []).filter((o) => originToHost(o) === displayHost);
    const errors = [];
    for (const raw of raws) {
      try {
        const okc = await chrome.permissions.remove({ origins: [raw] });
        if (!okc) {
          errors.push(`\u6D4F\u89C8\u5668\u62D2\u7EDD\u79FB\u9664\uFF1A${raw}`);
        }
      } catch (e) {
        errors.push(`${raw} \u2192 ${e instanceof Error ? e.message : String(e)}`);
      }
    }
    const leftover = ((await chrome.permissions.getAll()).origins ?? []).filter(
      (o) => originToHost(o) === displayHost || o.includes("*://*/*")
    );
    const stillCovers = leftover.length > 0;
    const blockedStored = await chrome.storage.local.get(LOCAL_KEYS.blockedHosts);
    const blocked = new Set(blockedStored[LOCAL_KEYS.blockedHosts] ?? []);
    if (stillCovers) {
      blocked.add(displayHost);
      await chrome.storage.local.set({ [LOCAL_KEYS.blockedHosts]: Array.from(blocked).sort() });
      alert(
        `\u300C${displayHost}\u300D\u5DF2\u5728 QuickLogin \u4E2D\u505C\u7528\uFF08\u6539\u5934\u89C4\u5219\u7ACB\u5373\u5931\u6548\uFF09\u3002

\u6D4F\u89C8\u5668\u5E95\u5C42\u6388\u6743\u672A\u80FD\u56DE\u6536\uFF1A
${errors.join("\n") || "(\u65E0\u660E\u7EC6)"}

\u5982\u9700\u5F7B\u5E95\u56DE\u6536\u6D4F\u89C8\u5668\u5C42\u6743\u9650\uFF1Achrome://extensions \u2192 \u8BE6\u60C5 \u2192 \u7F51\u7AD9\u8BBF\u95EE\u6743\u9650 \u2192 \u624B\u52A8\u6536\u7A84\u3002`
      );
    } else if (blocked.has(displayHost)) {
      blocked.delete(displayHost);
      await chrome.storage.local.set({ [LOCAL_KEYS.blockedHosts]: Array.from(blocked).sort() });
    }
    await send({ kind: "par.grantChanged" });
    await refreshAll();
  }
  async function unblockHost(host) {
    const stored = await chrome.storage.local.get(LOCAL_KEYS.blockedHosts);
    const blocked = new Set(stored[LOCAL_KEYS.blockedHosts] ?? []);
    blocked.delete(host);
    await chrome.storage.local.set({ [LOCAL_KEYS.blockedHosts]: Array.from(blocked).sort() });
    await send({ kind: "par.grantChanged" });
    await refreshAll();
  }
  async function fillSiteOptions() {
    const key = grantedHosts.join("|");
    if (key === lastHostOptions && pHostSelect.options.length) {
      return;
    }
    lastHostOptions = key;
    pHostSelect.innerHTML = "";
    if (!grantedHosts.length) {
      const empty = document.createElement("option");
      empty.value = "";
      empty.disabled = true;
      empty.selected = true;
      empty.textContent = "\uFF08\u6682\u65E0\u5DF2\u6388\u6743\u7AD9\u70B9 \u2014\u2014 \u8BF7\u5728\u300C\u7AD9\u70B9\u7BA1\u7406\u300D\u6DFB\u52A0\uFF09";
      pHostSelect.append(empty);
      return;
    }
    for (const h of grantedHosts) {
      const opt = document.createElement("option");
      opt.value = h;
      opt.textContent = h;
      pHostSelect.append(opt);
    }
    const stored = await chrome.storage.local.get(LAST_HOST_KEY);
    const last = stored[LAST_HOST_KEY];
    const preferred = last && grantedHosts.includes(last) ? last : grantedHosts.includes(PREFERRED_HOST) ? PREFERRED_HOST : grantedHosts[0];
    pHostSelect.value = preferred;
  }
  async function fillBoxOptions() {
    const key = boxes.join("|");
    if (key === lastBoxOptions && pBoxSelect.options.length) {
      return;
    }
    lastBoxOptions = key;
    pBoxSelect.innerHTML = "";
    for (const name of boxes) {
      const opt = document.createElement("option");
      opt.value = name;
      opt.textContent = name;
      pBoxSelect.append(opt);
    }
    const stored = await chrome.storage.local.get(LAST_BOX_KEY);
    const last = stored[LAST_BOX_KEY];
    pBoxSelect.value = currentBox !== "\u5168\u90E8" && boxes.includes(currentBox) ? currentBox : last && boxes.includes(last) ? last : defaultBox;
  }
  siteForm.addEventListener("submit", (e) => {
    e.preventDefault();
    const host = sHost.value.trim().replace(/^https?:\/\//, "").replace(/\/.*$/, "");
    if (!host) {
      return;
    }
    void (async () => {
      const ok = await chrome.permissions.request({ origins: [patternOfHost(host)] }).catch(() => false);
      if (!ok) {
        alert(`\u672A\u5B8C\u6210\u6388\u6743\uFF1A${host}`);
        return;
      }
      sHost.value = "";
      await send({ kind: "par.grantChanged" });
      await refreshAll();
    })();
  });
  async function refreshAll() {
    await loadBoxes();
    await loadBrowserAccounts();
    await loadSites();
    renderBoxChips();
    await fillSiteOptions();
    await fillBoxOptions();
    syncBatchBar();
  }
  void refreshAll();
  setInterval(() => void refreshAll(), 3e3);
})();

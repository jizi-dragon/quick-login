"use strict";
(() => {
  // packages/extension/src/content/shield-main.ts
  (() => {
    const win = window;
    if (win.__QL_SHIELD_INSTALLED__) {
      return;
    }
    win.__QL_SHIELD_INSTALLED__ = true;
    const WATCH_KEYS = ["__auth_token__", "__auth_user__", "__device_fp__"];
    const TOKEN_KEY = "__auth_token__";
    const NS_TAG = "__ql_ns_";
    const COOKIE_BAG_KEY = "__ql_cookies__";
    const BOOT_GUARD_KEY = "__ql_boot_guard";
    const SRC_PAGE_TO_BRIDGE = "QL_PAGE_TO_BRIDGE";
    const SRC_BRIDGE_TO_PAGE = "QL_BRIDGE_TO_PAGE";
    let mode = "passthrough";
    let ns = "";
    let settled = false;
    const CACHE_PARTITION_ENABLED = true;
    let tabIdForCache = null;
    const proto = Storage.prototype;
    const origGetItem = proto.getItem;
    const origSetItem = proto.setItem;
    const origRemoveItem = proto.removeItem;
    const origKey = proto.key;
    const origLengthDesc = Object.getOwnPropertyDescriptor(proto, "length");
    const cookieDesc = Object.getOwnPropertyDescriptor(Document.prototype, "cookie") ?? Object.getOwnPropertyDescriptor(document, "cookie");
    let bag = null;
    function loadBag() {
      if (bag) {
        return bag;
      }
      try {
        bag = JSON.parse(origGetItem.call(window.localStorage, ns + COOKIE_BAG_KEY) ?? "{}");
      } catch {
        bag = {};
      }
      if (typeof bag !== "object" || bag === null) {
        bag = {};
      }
      return bag;
    }
    function saveBag() {
      try {
        origSetItem.call(window.localStorage, ns + COOKIE_BAG_KEY, JSON.stringify(loadBag()));
      } catch {
      }
    }
    function bagSet(key, value) {
      loadBag();
      if (value === "") {
        delete bag[key];
      } else {
        bag[key] = value;
      }
      saveBag();
    }
    function installCookieVirtualization() {
      if (!cookieDesc?.configurable) {
        return;
      }
      Object.defineProperty(document, "cookie", {
        configurable: true,
        get() {
          const b = loadBag();
          return Object.entries(b).map(([k, v]) => `${k}=${v}`).join("; ");
        },
        set(text) {
          const firstChunk = String(text).split(";")[0] ?? "";
          const eq = firstChunk.indexOf("=");
          if (eq <= 0) {
            return;
          }
          const key = firstChunk.slice(0, eq).trim();
          const value = firstChunk.slice(eq + 1).trim();
          if (!key) {
            return;
          }
          bagSet(key, decodeURIComponentSafe(value));
        }
      });
    }
    function decodeURIComponentSafe(v) {
      try {
        return decodeURIComponent(v);
      } catch {
        return v;
      }
    }
    function reportStorageWrite(key, value) {
      if (!WATCH_KEYS.includes(key)) {
        return;
      }
      window.postMessage(
        { src: SRC_PAGE_TO_BRIDGE, payload: { op: "storageWrite", key, value } },
        "*"
      );
    }
    function reportAuthHeader(value) {
      window.postMessage(
        { src: SRC_PAGE_TO_BRIDGE, payload: { op: "authHeader", value } },
        "*"
      );
    }
    function cachePartitionUrl(rawUrl) {
      if (!CACHE_PARTITION_ENABLED || tabIdForCache === null) {
        return rawUrl;
      }
      try {
        const u = new URL(rawUrl, location.href);
        if (u.host !== location.host) {
          return rawUrl;
        }
        if (u.searchParams.has("_qlck")) {
          return rawUrl;
        }
        u.searchParams.set("_qlck", `t${tabIdForCache}`);
        return u.href;
      } catch {
        return rawUrl;
      }
    }
    function patchNetworkSniffers() {
      const nativeFetch = win.fetch;
      const sniffFetch = function(input, init) {
        try {
          let method = "GET";
          let urlStr;
          if (input instanceof Request) {
            method = input.method;
            urlStr = input.url;
          } else if (typeof input === "string") {
            urlStr = input;
          } else if (input instanceof URL) {
            urlStr = input.href;
          } else {
            urlStr = String(input);
          }
          if (typeof init?.method === "string") {
            method = init.method;
          }
          if (method.toUpperCase() === "GET") {
            const partitioned = cachePartitionUrl(urlStr);
            if (partitioned !== urlStr) {
              if (input instanceof Request) {
                input = new Request(partitioned, input);
              } else {
                input = partitioned;
              }
            }
          }
          let headers;
          if (init && init.headers) {
            headers = new Headers(init.headers);
          } else if (input instanceof Request) {
            headers = input.headers;
          }
          const auth = headers?.get("authorization");
          if (auth) {
            reportAuthHeader(auth);
          }
        } catch {
        }
        return nativeFetch.call(this, input, init);
      };
      win.fetch = sniffFetch;
      const xhrProto = XMLHttpRequest.prototype;
      const nativeOpen = xhrProto.open;
      const nativeSetHeader = xhrProto.setRequestHeader;
      const nativeSend = xhrProto.send;
      const AUTH_SLOT = Symbol("__ql_auth__");
      xhrProto.open = function(method, url, ...rest) {
        let u = String(url);
        if (String(method).toUpperCase() === "GET") {
          const partitioned = cachePartitionUrl(u);
          if (partitioned !== u) {
            u = partitioned;
          }
        }
        nativeOpen.call(this, method, u, ...rest);
      };
      xhrProto.setRequestHeader = function(name, value) {
        if (name.toLowerCase() === "authorization") {
          this[AUTH_SLOT] = value;
        }
        nativeSetHeader.call(this, name, value);
      };
      xhrProto.send = function(body) {
        const auth = this[AUTH_SLOT];
        if (auth) {
          reportAuthHeader(auth);
        }
        return nativeSend.apply(this, [body]);
      };
    }
    function realLength(storage) {
      if (origLengthDesc && origLengthDesc.get) {
        return origLengthDesc.get.call(storage);
      }
      return 0;
    }
    function namespaceKeys(storage) {
      const out = [];
      const len = realLength(storage);
      for (let i = 0; i < len; i++) {
        const k = origKey.call(storage, i);
        if (k !== null && k.startsWith(ns)) {
          out.push(k);
        }
      }
      return out;
    }
    function onNamespaceWrite(storage, bareKey, rawKey, value) {
      if (bareKey === TOKEN_KEY) {
        if (value === null) {
          bagSet(TOKEN_KEY, "");
          origRemoveItem.call(storage, rawKey);
        } else {
          bagSet(TOKEN_KEY, value);
        }
      }
      reportStorageWrite(bareKey, value);
    }
    function installStoragePatch() {
      Object.defineProperty(proto, "getItem", {
        configurable: true,
        writable: true,
        value: function(key) {
          return origGetItem.call(this, ns + String(key));
        }
      });
      Object.defineProperty(proto, "setItem", {
        configurable: true,
        writable: true,
        value: function(key, value) {
          const bare = String(key);
          const raw = ns + bare;
          const val = String(value);
          origSetItem.call(this, raw, val);
          onNamespaceWrite(this, bare, raw, val);
        }
      });
      Object.defineProperty(proto, "removeItem", {
        configurable: true,
        writable: true,
        value: function(key) {
          const bare = String(key);
          const raw = ns + bare;
          origRemoveItem.call(this, raw);
          onNamespaceWrite(this, bare, raw, null);
        }
      });
      Object.defineProperty(proto, "clear", {
        configurable: true,
        writable: true,
        value: function() {
          for (const raw of namespaceKeys(this)) {
            origRemoveItem.call(this, raw);
          }
          bag = {};
          saveBag();
        }
      });
      Object.defineProperty(proto, "key", {
        configurable: true,
        writable: true,
        value: function(index) {
          const keys = namespaceKeys(this).filter((k) => k !== ns + COOKIE_BAG_KEY);
          if (!Number.isInteger(index) || index < 0 || index >= keys.length) {
            return null;
          }
          return keys[index].slice(ns.length);
        }
      });
      Object.defineProperty(proto, "length", {
        configurable: true,
        get: function() {
          return namespaceKeys(this).filter((k) => k !== ns + COOKIE_BAG_KEY).length;
        }
      });
      installCookieVirtualization();
      patchNetworkSniffers();
    }
    const SW_SHIELD_ENABLED = true;
    function installSwAndCacheShield() {
      try {
        const swProto = window.ServiceWorkerContainer?.prototype;
        const swCtl = navigator.serviceWorker;
        if (SW_SHIELD_ENABLED && swProto && swCtl && typeof swProto.register === "function") {
          const desc = Object.getOwnPropertyDescriptor(swProto, "register");
          if (!desc || desc.configurable) {
            Object.defineProperty(swProto, "register", {
              configurable: true,
              writable: true,
              // 阻断注册：站点回调 .catch 分支即可，不中断业务代码
              value: () => Promise.reject(new Error("QuickLogin: site Service Worker disabled for bound tab"))
            });
          }
          if (typeof swCtl.getRegistrations === "function") {
            void Promise.resolve(swCtl.getRegistrations()).then((regs) => {
              for (const r of regs ?? []) {
                try {
                  void r.unregister();
                } catch {
                }
              }
            }).catch(() => void 0);
          }
        }
        const CacheStorageProto = window.CacheStorage?.prototype;
        if (SW_SHIELD_ENABLED && CacheStorageProto && typeof CacheStorageProto.open === "function") {
          const oOpen = CacheStorageProto.open;
          const oKeys = CacheStorageProto.keys;
          const oHas = CacheStorageProto.has;
          const oDelete = CacheStorageProto.delete;
          const patch = (proto2, key, value) => {
            const d = Object.getOwnPropertyDescriptor(proto2, key);
            if (!d || d.configurable) {
              Object.defineProperty(proto2, key, { configurable: true, writable: true, value });
            }
          };
          patch(CacheStorageProto, "open", function(name) {
            return oOpen.call(this, ns + String(name));
          });
          patch(CacheStorageProto, "keys", function() {
            return Promise.resolve(oKeys.call(this)).then(
              (arr) => arr.filter((k) => k.startsWith(ns)).map((k) => k.slice(ns.length))
            );
          });
          patch(CacheStorageProto, "has", function(name) {
            return oHas.call(this, ns + String(name));
          });
          patch(CacheStorageProto, "delete", function(name) {
            return oDelete.call(this, ns + String(name));
          });
          patch(CacheStorageProto, "match", function() {
            return Promise.resolve(void 0);
          });
        }
      } catch {
      }
    }
    function installBroadcastShield() {
      try {
        const BCtor = window.BroadcastChannel;
        if (!BCtor) {
          return;
        }
        class NSBroadcastChannel extends BCtor {
          constructor(name) {
            super(ns + String(name));
          }
        }
        Object.defineProperty(window, "BroadcastChannel", {
          configurable: true,
          writable: true,
          value: NSBroadcastChannel
        });
      } catch {
      }
    }
    const IDB_SHIELD_ENABLED = true;
    function installIdbShield() {
      try {
        if (!IDB_SHIELD_ENABLED || typeof IDBFactory === "undefined") {
          return;
        }
        const idbProto = IDBFactory.prototype;
        const oOpen = idbProto.open;
        const oDelete = idbProto.deleteDatabase;
        const oDatabases = idbProto.databases;
        const patch = (proto2, key, value) => {
          const d = Object.getOwnPropertyDescriptor(proto2, key);
          if (!d || d.configurable) {
            Object.defineProperty(proto2, key, { configurable: true, writable: true, value });
          }
        };
        patch(idbProto, "open", function(name, version) {
          return version === void 0 ? oOpen.call(this, ns + String(name)) : oOpen.call(this, ns + String(name), version);
        });
        patch(idbProto, "deleteDatabase", function(name) {
          return oDelete.call(this, ns + String(name));
        });
        if (typeof oDatabases === "function") {
          patch(idbProto, "databases", function() {
            return Promise.resolve(oDatabases.call(this)).then(
              (infos) => (infos ?? []).filter((i) => typeof i.name === "string" && i.name.startsWith(ns)).map((i) => ({ ...i, name: i.name.slice(ns.length) }))
            );
          });
        }
      } catch {
      }
    }
    function activate(accountId, seed) {
      if (mode === "active") {
        return;
      }
      mode = "active";
      ns = `${NS_TAG}${accountId}__`;
      installStoragePatch();
      installSwAndCacheShield();
      installBroadcastShield();
      installIdbShield();
      applySeed(seed);
    }
    function applySeed(seed) {
      if (!seed) {
        return;
      }
      for (const [key, value] of Object.entries(seed)) {
        if (typeof value !== "string" || !value) {
          continue;
        }
        try {
          origSetItem.call(window.localStorage, ns + key, value);
          if (key === TOKEN_KEY) {
            bagSet(TOKEN_KEY, value);
          }
        } catch {
        }
      }
    }
    function handleBind(accountId, seed, tabId) {
      if (typeof tabId === "number") {
        tabIdForCache = tabId;
      }
      if (settled) {
        applySeed(seed);
        return;
      }
      settled = true;
      if (document.readyState === "loading") {
        activate(accountId, seed);
        return;
      }
      if (window.sessionStorage.getItem(BOOT_GUARD_KEY) === "1") {
        window.sessionStorage.removeItem(BOOT_GUARD_KEY);
        activate(accountId, seed);
        return;
      }
      window.sessionStorage.setItem(BOOT_GUARD_KEY, "1");
      window.location.reload();
    }
    window.addEventListener("message", (event) => {
      if (event.source !== window) {
        return;
      }
      const data = event.data;
      if (!data || data.src !== SRC_BRIDGE_TO_PAGE) {
        return;
      }
      const payload = data.payload;
      if (payload && payload.op === "bind" && typeof payload.accountId === "string") {
        handleBind(payload.accountId, payload.seed, typeof payload.tabId === "number" ? payload.tabId : void 0);
      } else if (payload && payload.op === "unbound") {
        settled = true;
      }
    });
    function hello(attempt) {
      if (attempt <= 0) {
        return;
      }
      window.setTimeout(() => {
        if (!settled) {
          window.postMessage(
            { src: SRC_PAGE_TO_BRIDGE, payload: { op: "hello", url: location.href } },
            "*"
          );
          hello(attempt - 1);
        }
      }, 120);
    }
    window.postMessage({ src: SRC_PAGE_TO_BRIDGE, payload: { op: "hello", url: location.href } }, "*");
    hello(6);
  })();
})();

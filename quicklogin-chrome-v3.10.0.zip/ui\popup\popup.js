"use strict";
(() => {
  // packages/extension/src/shared/constants.ts
  var EXT_VERSION = "3.10.0";

  // packages/extension/src/ui/popup/popup.ts
  document.getElementById("ext-version").textContent = `v${EXT_VERSION}`;
  function openParallelPage() {
    chrome.tabs.create({ url: chrome.runtime.getURL("ui/parallel/parallel.html") });
    window.close();
  }
  document.getElementById("open-parallel").addEventListener("click", openParallelPage);
  function setStat(id, value) {
    const el = document.getElementById(id);
    if (el) {
      el.textContent = String(value);
    }
  }
  void (async () => {
    try {
      const res = await chrome.runtime.sendMessage({ kind: "par.list" });
      const accounts = res?.result?.ok && Array.isArray(res.result.data) ? res.result.data : [];
      setStat("stat-accounts", accounts.length);
      setStat("stat-online", accounts.filter((a) => (a.tabIds?.length ?? 0) > 0).length);
    } catch {
      setStat("stat-accounts", "\u2014");
      setStat("stat-online", "\u2014");
    }
    try {
      const all = await chrome.permissions.getAll();
      const hosts = /* @__PURE__ */ new Set();
      for (const o of all.origins ?? []) {
        const m = /^(?:\*|https?):\/\/([^/]+)(?:\/.*)?$/.exec(o);
        if (m && m[1] !== "*") {
          hosts.add(m[1]);
        }
      }
      setStat("stat-sites", hosts.size);
    } catch {
      setStat("stat-sites", "\u2014");
    }
  })();
})();

"use strict";
(() => {
  // packages/extension/src/shared/constants.ts
  var LOCAL_KEYS = {
    siteGrants: "sb:siteGrants",
    /** 手动停用的站点（Chrome 拒绝回收授权时本地封锁，不再对其安装改头规则） */
    blockedHosts: "ql:blockedHosts",
    /** 记忆的盒子清单（空盒子也保留；缺省「默认盒子」不入库） */
    boxList: "ql:boxes",
    /** 默认盒子的自定义名称（未归盒账号的归宿；缺省「默认盒子」） */
    defaultBox: "ql:defaultBox",
    /** 被禁用的盒子名单（轮盘跳过切换；空默认盒自动禁用） */
    disabledBoxes: "ql:disabledBoxes"
  };

  // packages/extension/src/ui/wheel/wheel-core.ts
  var WHEEL_MAX = 10;
  var NS = "http://www.w3.org/2000/svg";
  var SIZE = 520;
  var C = SIZE / 2;
  var R_OUT = 240;
  var R_IN = 118;
  var R_ARC = 254;
  var GAP_DEG = 2;
  var DEFAULT_BOX = "\u9ED8\u8BA4\u76D2\u5B50";
  function polar(r, deg) {
    const a = (deg - 90) * Math.PI / 180;
    return { x: C + r * Math.cos(a), y: C + r * Math.sin(a) };
  }
  function sectorPath(a0, a1) {
    const s = a0 + GAP_DEG / 2;
    const e = a1 - GAP_DEG / 2;
    const large = e - s > 180 ? 1 : 0;
    const p1 = polar(R_OUT, s);
    const p2 = polar(R_OUT, e);
    const p3 = polar(R_IN, e);
    const p4 = polar(R_IN, s);
    return [
      `M ${p1.x} ${p1.y}`,
      `A ${R_OUT} ${R_OUT} 0 ${large} 1 ${p2.x} ${p2.y}`,
      `L ${p3.x} ${p3.y}`,
      `A ${R_IN} ${R_IN} 0 ${large} 0 ${p4.x} ${p4.y}`,
      "Z"
    ].join(" ");
  }
  function el(name, attrs) {
    const node = document.createElementNS(NS, name);
    for (const [k, v] of Object.entries(attrs)) {
      node.setAttribute(k, String(v));
    }
    return node;
  }
  function radialText(cls, mid, r, content) {
    const p = polar(r, mid);
    const flip = mid > 90 && mid < 270;
    const rot = flip ? mid + 180 : mid;
    const t = el("text", {
      class: cls,
      x: p.x,
      y: p.y,
      "text-anchor": "middle",
      "dominant-baseline": "central",
      transform: `rotate(${rot} ${p.x} ${p.y})`
    });
    t.textContent = content;
    return t;
  }
  function truncate(s, max) {
    return s.length > max ? `${s.slice(0, max - 1)}\u2026` : s;
  }
  function groupPagesByBox(accounts, defaultBoxName = DEFAULT_BOX) {
    const pages2 = [];
    const byName = /* @__PURE__ */ new Map();
    for (const a of accounts) {
      const name = a.box?.trim() || defaultBoxName;
      if (!byName.has(name)) {
        byName.set(name, []);
        pages2.push({ label: name, accounts: byName.get(name) });
      }
      byName.get(name).push(a);
    }
    return pages2;
  }
  function buildSectorWheel(root, opts) {
    root.innerHTML = "";
    root.classList.add("sector-wheel");
    const pages2 = opts.pages;
    const page = pages2[opts.pageIndex];
    const accounts = page?.accounts ?? [];
    const list = accounts.slice(0, WHEEL_MAX);
    const n = list.length;
    const onlineCount = accounts.filter((a) => (a.tabIds?.length ?? 0) > 0).length;
    const overflow = accounts.length > WHEEL_MAX;
    const pageCount = pages2.length;
    const pagePos = pageCount > 0 ? opts.pageIndex % pageCount + 1 : 0;
    const svg = el("svg", { class: "sector-svg", viewBox: `-18 0 596 520` });
    const defs = el("defs", {});
    const grad = el("linearGradient", {
      id: "qlBoxGrad",
      gradientUnits: "userSpaceOnUse",
      x1: "387",
      y1: "40",
      x2: "387",
      y2: "480"
    });
    grad.append(
      el("stop", { offset: "0%", "stop-color": "#1E6FFF" }),
      el("stop", { offset: "55%", "stop-color": "#7C5CFF" }),
      el("stop", { offset: "100%", "stop-color": "#22C55E" })
    );
    defs.append(grad);
    svg.append(defs);
    const arcPt = (deg) => ({
      x: +(C + R_ARC * Math.cos(deg * Math.PI / 180)).toFixed(2),
      y: +(C + R_ARC * Math.sin(deg * Math.PI / 180)).toFixed(2)
    });
    const ARC_FROM = -60;
    const ARC_TO = 60;
    const pa = arcPt(ARC_FROM);
    const pb = arcPt(ARC_TO);
    svg.append(el("path", { class: "box-track", d: `M ${pa.x} ${pa.y} A ${R_ARC} ${R_ARC} 0 0 1 ${pb.x} ${pb.y}` }));
    const nodeAngle = (i) => pageCount > 1 ? ARC_FROM + (ARC_TO - ARC_FROM) * i / (pageCount - 1) : 0;
    for (let i = 0; i < pageCount; i++) {
      const pt = arcPt(nodeAngle(i));
      svg.append(el("circle", { class: "box-node", cx: pt.x, cy: pt.y, r: 5 }));
    }
    const curIdx = pageCount > 0 ? (opts.pageIndex % pageCount + pageCount) % pageCount : 0;
    const cur = arcPt(nodeAngle(curIdx));
    const labR = R_ARC + 22;
    const lab = {
      x: +(C + labR * Math.cos(nodeAngle(curIdx) * Math.PI / 180)).toFixed(2),
      y: +(C + labR * Math.sin(nodeAngle(curIdx) * Math.PI / 180)).toFixed(2)
    };
    const activeG = el("g", { class: "box-node-on-g" });
    activeG.append(el("circle", { class: "box-node-on", cx: cur.x, cy: cur.y, r: 7 }));
    const label = el("text", {
      class: "box-node-label",
      x: lab.x,
      y: lab.y,
      "text-anchor": "middle",
      "dominant-baseline": "central"
    });
    label.textContent = truncate(page?.label ?? DEFAULT_BOX, 5);
    activeG.append(label);
    svg.append(activeG);
    const prevRaw = Number(root.dataset.qlWheelLastIdx ?? NaN);
    root.dataset.qlWheelLastIdx = String(curIdx);
    if (!Number.isNaN(prevRaw) && prevRaw !== curIdx && prevRaw >= 0 && prevRaw < pageCount) {
      const prev = arcPt(nodeAngle(prevRaw));
      const mid = arcPt((nodeAngle(prevRaw) + nodeAngle(curIdx)) / 2);
      activeG.animate(
        [
          { transform: `translate(${(prev.x - cur.x).toFixed(2)}px, ${(prev.y - cur.y).toFixed(2)}px)` },
          { transform: `translate(${(mid.x - cur.x).toFixed(2)}px, ${(mid.y - cur.y).toFixed(2)}px)`, offset: 0.5 },
          { transform: "translate(0px, 0px)" }
        ],
        { duration: 280, easing: "cubic-bezier(0.3, 0.9, 0.35, 1)" }
      );
    }
    if (n === 0) {
      svg.append(el("circle", { class: "hub-bg", cx: C, cy: C, r: R_IN - 6 }));
      const allEmpty = pages2.every((p) => p.accounts.length === 0);
      const cap2 = el("text", { class: "hub-cap", x: C, y: C - 44, "text-anchor": "middle" });
      cap2.textContent = allEmpty ? "\u6682\u65E0\u5E76\u884C\u8D26\u53F7" : truncate(page?.label ?? DEFAULT_BOX, 10);
      const sub2 = el("text", { class: "hub-sub", x: C, y: C - 14, "text-anchor": "middle" });
      sub2.textContent = allEmpty ? "\u6DFB\u52A0\u8D26\u53F7\u540E\uFF0C\u8FD9\u91CC\u5373\u53EF\u5FEB\u901F\u5207\u6362\u8EAB\u4EFD" : "\u8BE5\u76D2\u5B50\u6682\u65E0\u8D26\u53F7 \xB7 \u6EDA\u8F6E\u6216\u70B9\u51FB Hub \u5207\u6362\u76D2\u5B50";
      svg.append(cap2, sub2);
      if (allEmpty && opts.emptyAction) {
        const goW = 150;
        const go = el("g", { class: "hub-go", tabindex: "0", role: "button" });
        go.append(el("rect", { class: "hub-go-rect", x: C - goW / 2, y: C + 10, width: goW, height: 38, rx: 19 }));
        const label2 = el("text", {
          class: "hub-go-text",
          x: C,
          y: C + 29,
          "text-anchor": "middle",
          "dominant-baseline": "central"
        });
        label2.textContent = opts.emptyAction.label;
        go.append(label2);
        go.addEventListener("click", () => opts.emptyAction.run());
        svg.append(go);
      }
      attachPageNav(root, opts);
      root.append(svg);
      return;
    }
    for (let i = 0; i < n; i++) {
      const account = list[i];
      const online = (account.tabIds?.length ?? 0) > 0;
      const a0 = 360 * i / n;
      const a1 = 360 * (i + 1) / n;
      const mid = (a0 + a1) / 2;
      const g = el("g", {
        class: `sector${online ? " is-online" : ""}`,
        style: `--acc:${account.color || "#1E6FFF"};--d:${(0.06 + i * 0.05).toFixed(2)}s`
      });
      g.append(el("path", { class: "sector-hit", d: sectorPath(a0, a1) }));
      const name = (account.tabName || account.username || "\u8D26\u53F7").trim();
      g.append(radialText("sector-label", mid, (R_IN + R_OUT) / 2 + 2, truncate(name, 8)));
      const numAt = polar(R_IN + 24, mid);
      const flip = mid > 90 && mid < 270;
      const numRot = flip ? mid + 180 : mid;
      const numG = el("g", { class: "sector-num", transform: `rotate(${numRot} ${numAt.x} ${numAt.y})` });
      numG.append(el("circle", { cx: numAt.x, cy: numAt.y, r: 11 }));
      const numText = el("text", { x: numAt.x, y: numAt.y, "text-anchor": "middle", "dominant-baseline": "central" });
      numText.textContent = String(i < 9 ? i + 1 : 0);
      numG.append(numText);
      g.append(numG);
      const dotAt = polar(R_OUT - 22, mid);
      g.append(el("circle", { class: `sector-dot${online ? " on" : ""}`, cx: dotAt.x, cy: dotAt.y, r: 5.5 }));
      g.addEventListener("click", () => opts.onPick(account.id));
      svg.append(g);
    }
    const hub = el("g", { class: "hub hub-click" });
    hub.append(el("circle", { class: "hub-bg", cx: C, cy: C, r: R_IN - 8 }));
    const cap = el("text", { class: "hub-box", x: C, y: C - 46, "text-anchor": "middle" });
    cap.textContent = truncate(page.label, 10);
    const num = el("text", { class: "hub-num", x: C, y: C + 6, "text-anchor": "middle", "dominant-baseline": "central" });
    num.append(document.createTextNode(String(onlineCount)));
    const den = el("tspan", { class: "den", dx: 3 });
    den.textContent = `/ ${n} \u5728\u7EBF`;
    num.append(den);
    const sub = el("text", { class: "hub-sub", x: C, y: C + 40, "text-anchor": "middle" });
    sub.textContent = overflow ? `\u76D2\u5B50\u5185 ${accounts.length} \u4E2A \xB7 \u4EC5\u663E\u793A\u524D ${WHEEL_MAX} \u4E2A` : `\u76D2\u5B50 ${pagePos}/${pageCount} \xB7 \u6EDA\u8F6E\u6216\u70B9\u51FB\u5207\u76D2`;
    hub.append(cap, num, sub);
    hub.addEventListener("click", () => opts.onPage(1));
    svg.append(hub);
    attachPageNav(root, opts);
    root.append(svg);
  }
  function attachPageNav(root, opts) {
    if (root.dataset.qlWheelNav === "1") {
      return;
    }
    root.dataset.qlWheelNav = "1";
    root.addEventListener(
      "wheel",
      (e) => {
        e.preventDefault();
        opts.onPage(e.deltaY > 0 ? 1 : -1);
      },
      { passive: false }
    );
  }

  // packages/extension/src/ui/wheel/wheel.ts
  var wheelEl = document.getElementById("wheel");
  var PARALLEL_PAGE = chrome.runtime.getURL("ui/parallel/parallel.html");
  var blurArmed = false;
  window.setTimeout(() => {
    blurArmed = true;
  }, 400);
  window.addEventListener("blur", () => {
    if (blurArmed) {
      window.close();
    }
  });
  void window.focus();
  async function fetchAccounts() {
    const res = await chrome.runtime.sendMessage({ kind: "par.list" });
    if (!res?.result?.ok || !Array.isArray(res.result.data)) {
      return [];
    }
    return res.result.data;
  }
  async function fetchPages() {
    const [accounts, remembered, defaultBoxStore, disabledStore] = await Promise.all([
      fetchAccounts(),
      chrome.storage.local.get(LOCAL_KEYS.boxList).then((s) => s[LOCAL_KEYS.boxList] ?? []).catch(() => []),
      chrome.storage.local.get(LOCAL_KEYS.defaultBox).then((s) => s[LOCAL_KEYS.defaultBox]?.trim() ?? "").catch(() => ""),
      chrome.storage.local.get(LOCAL_KEYS.disabledBoxes).then((s) => s[LOCAL_KEYS.disabledBoxes] ?? []).catch(() => [])
    ]);
    const disabled = new Set(disabledStore);
    const pages2 = groupPagesByBox(accounts, defaultBoxStore || DEFAULT_BOX).filter((p) => !disabled.has(p.label));
    const seen = new Set(pages2.map((p) => p.label));
    for (const name of remembered) {
      if (!seen.has(name) && name !== defaultBoxStore && !disabled.has(name)) {
        pages2.push({ label: name, accounts: [] });
      }
    }
    return pages2;
  }
  async function pick(accountId) {
    try {
      await chrome.runtime.sendMessage({ kind: "par.open", id: accountId });
    } finally {
      window.close();
    }
  }
  var pages = [];
  var pageIndex = 0;
  function render() {
    buildSectorWheel(wheelEl, {
      pages,
      pageIndex,
      onPage: (delta) => {
        if (!pages.length) {
          return;
        }
        pageIndex = (pageIndex + delta + pages.length) % pages.length;
        render();
        requestAnimationFrame(() => requestAnimationFrame(() => wheelEl.classList.add("in")));
      },
      onPick: (id) => void pick(id),
      emptyAction: {
        label: "\u53BB\u5E76\u884C\u7BA1\u7406\u9875\u6DFB\u52A0",
        run: async () => {
          await chrome.tabs.create({ url: PARALLEL_PAGE });
          window.close();
        }
      }
    });
    requestAnimationFrame(() => requestAnimationFrame(() => wheelEl.classList.add("in")));
  }
  function onKey(e) {
    if (e.key === "Escape") {
      e.preventDefault();
      window.close();
      return;
    }
    const page = pages[pageIndex];
    if (!page) {
      return;
    }
    const idx = Number(e.key) === 0 ? 9 : Number(e.key) - 1;
    if (!Number.isNaN(idx) && idx >= 0 && idx < 10 && idx < page.accounts.length) {
      void pick(page.accounts[idx].id);
    }
  }
  var lastFingerprint = "";
  function fingerprint(grouped) {
    return JSON.stringify(grouped.map((p) => [p.label, p.accounts.map((a) => a.id)]));
  }
  async function refresh() {
    const grouped = await fetchPages();
    const fp = fingerprint(grouped);
    if (fp === lastFingerprint) {
      return;
    }
    lastFingerprint = fp;
    pages = grouped;
    if (pageIndex >= pages.length) {
      pageIndex = Math.max(0, pages.length - 1);
    }
    render();
    requestAnimationFrame(() => requestAnimationFrame(() => wheelEl.classList.add("in")));
  }
  void refresh().then(() => {
    document.addEventListener("keydown", onKey);
  });
  window.setInterval(() => void refresh(), 3e3);
})();
